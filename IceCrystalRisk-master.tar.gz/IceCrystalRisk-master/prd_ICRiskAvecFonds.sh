#! /bin/sh
#------------------------------------------------------------------------------
# @(#)prd_IWCgeotiff.sh version 1.6 du 23/12/2022. (C) METEO-FRANCE
#------------------------------------------------------------------------------
#++
# NOM
#	prd_ICRiskAvecFonds
#
# SOMMAIRE
#	Pour fabriquer un produit avec des repères, du type "fonds de cartes", à partir du 
#   produit destiné à synopsis ("globe*IceCrystRiskGT").
#
#	Application :  imgICRisk
#
# DOMAINE D'INTÉGRATION.
#	cms
#
# SYNTAXE
#	prd_IWCgeotiff -S srcid -P prdid -s satimg -d yyyymmdd -h hhmn -n sssss file_src
#
# DESCRIPTION
#	- Consomme la source globe*IceCrystRiskGT, produit sur chacune des 5 chaines traitant
#     les géostationnaires.

# OPTIONS
#
#	-S srcid
#	identificateur de la source : globeMhiwcMaskNC
#	Cette cle est obligatoire.
#
#	-P prdid
#	identificateur du produit : globeMhiwcMaskGT
#	Cette cle est obligatoire.
#
#	-s satimg
#	identificateur du satellite image (ex: msg04)
#	Cette cle est obligatoire.
#
#	-d yyyymmdd
#	date de reference de la (des) source(s)
#	Cette cle est obligatoire.
#
#	-h hhmn[ss]
#	heure de reference de la (des) source(s)
#	ss vaut 00 si non precise
#	Cette cle est obligatoire.
#
#	-n sssss
#	numero de slot de la (des) source(s)
#	Cette cle est optionnelle.
#
# ENVIRONNEMENT
#	ArchiPEL
#
# FICHIERS
#
# NOTES
#
# AUTEUR(S)
# SG 
# DATE DE CRÉATION
#	01/06/2023
# DERNIÈRE MODIFICATION
#   01/06/2023
# VERSION.RELEASE
#	1.0
#--
#	
#==============================================================================
# fonctions specifiques
#==============================================================================

#------------------------------------------------------------------------------
app_exit()
#------------------------------------------------------------------------------
	{
	log_info $2
	#if [ -d $TEMP ] ; then
	#	rm -rf $TEMP
	#fi
	exit $1
	}

#------------------------------------------------------------------------------
test_exit()
#------------------------------------------------------------------------------
	{
	if [ $1 -ne 0 ] ; then
		app_exit $1 $2
	fi
	}

#------------------------------------------------------------------------------
teste_fichier_present()
#------------------------------------------------------------------------------
	{
	if [ ! -r "$1" ]; then
		log_error "Il manque le fichier $1 ou ce fichier n'est pas lisible"
		app_exit 2 
	fi
	}

# #-------------------------------------------------------------------------------
# app_add_Tag()
# #-------------------------------------------------------------------------------
# 	{
# 	FILE_IN=$1

# 	VRT=${ARCHIPEL_dir}/test$$.vrt
# 	log_info "gdalbuildvrt -q $VRT $FILE_IN"
# 	gdalbuildvrt -q $VRT $FILE_IN
# 	test_exit $? "gdalbuildvrt"

# 	# Section non modifiée.
# 	SEG_0=`head -n 1 $VRT`
# 	NB_LINE=`wc -l $VRT|cut -d" " -f1`
# 	ind=`expr $NB_LINE - 1`

# 	# section non modifiee
# 	SEG_2=`tail -n $ind $VRT`

# 	# Section à intercaler.
# 	NOM_PRD=`basename $FILE_IN|cut -d"." -f1`
# 	#FIXED 2020-01-20 FB
# 	SAT=`basename $FILE_IN |cut -d'_' -f2` #ex : msg04
# 	if [ $SAT = 'msg01' ]; then 
# 		VAL_K_process_SAT_stdname=msg1
# 		VAL_K_process_SAT_longname=met8
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}-${VAL_K_process_SAT_longname}"
# 	elif [ $SAT = 'msg02'	]; then	
# 		VAL_K_process_SAT_stdname=msg2
# 		VAL_K_process_SAT_longname=met9
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}-${VAL_K_process_SAT_longname}"
# 	elif [ $SAT = 'msg03'	]; then	
# 		VAL_K_process_SAT_stdname=msg3
# 		VAL_K_process_SAT_longname=met10
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}-${VAL_K_process_SAT_longname}"
# 	elif [ $SAT = 'msg04'	]; then	
# 		VAL_K_process_SAT_stdname=msg4
# 		VAL_K_process_SAT_longname=met11
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}-${VAL_K_process_SAT_longname}"
# 	elif [ $SAT = 'goes16'	]; then	
# 		VAL_K_process_SAT_stdname=goes16
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}"
# 	elif [ $SAT = 'goes17'	]; then	
# 		VAL_K_process_SAT_stdname=goes17
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}"
# 	elif [ $SAT = 'goes18'	]; then	
# 		VAL_K_process_SAT_stdname=goes18
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}"
# 	elif [ $SAT = 'hima08'	]; then	
# 		VAL_K_process_SAT_stdname=himawari8
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}"
# 	elif [ $SAT = 'hima09'	]; then	
# 		VAL_K_process_SAT_stdname=himawari9
# 		VAL_K_process="geostationary_${VAL_K_process_SAT_stdname}"

# 	# Rajout du 23/12/2022.
# 	elif [ "${SATIMG}" = "mtg01" ] || [ "${SATIMG}" = "mtgi1" ] ; then
# 		VAL_K_process=geostationary_mtgi1-met12
# 	elif [ "${SATIMG}" = "mtg02" ] || [ "${SATIMG}" = "mtgi2" ]  ; then
# 		VAL_K_process=geostationary_mtgi2-met14
# 	elif [ "${SATIMG}" = "mtg03" ] || [ "${SATIMG}" = "mtgi3" ]  ; then
# 		VAL_K_process=geostationary_mtgi3-met15
# 	elif [ "${SATIMG}" = "mtg04" ] || [ "${SATIMG}" = "mtgi4" ]  ; then
# 		VAL_K_process=geostationary_mtgi4-met17

# 	else 
# 		app_exit 1 "(app_add_Tag) Pb de reconnaissance du nom du satellite a partir du nom du fichier (${FILE_IN})"
# 	fi

# 	# Exemple : "geostationary_msg4-met11"
# 	VAL_K_aggregate="geostationary_iwc_nwc"
# 	YYYY=${YYYYMMDD:0:4}
# 	MM=${YYYYMMDD:4:2}
# 	DD=${YYYYMMDD:6:2}
# 	HH=${HHMN:0:2}
# 	MIN=${HHMN:2:2}
# 	SS=00

# 	# FIXED 2020-09-23 ajout de 15 minutes pour se caler sur l'imagerie std.
# 	# 15/03/2021 : ajout de 15 minutes uniquement pour les satellites msg et msgoi.

# 	if [ \( "$ARCHIPEL_ID" = 'msg' \) -o \( "$ARCHIPEL_ID" = 'msgbis' \) -o \( "$ARCHIPEL_ID" = 'msgoi' \) \
# 		-o \( "$ARCHIPEL_ID" = 'msgoibis' \) ] ; then
# 		log_info "ajout de 15 minutes pour se caler sur l'imagerie std : deltat ${YYYYMMDD}${HH}${MIN} + 15 mn"
# 		dateImagerie=`deltat ${YYYYMMDD}${HH}${MIN} + 15 mn`
# 		test_exit $? "deltat"
# 		YYYY=${dateImagerie:0:4}
# 		MM=${dateImagerie:4:2}
# 		DD=${dateImagerie:6:2}
# 		HH=${dateImagerie:8:2}
# 		MIN=${dateImagerie:10:2}

# 	elif [[ "${ARCHIPEL_ID}" == *mtg* ]] ; then
# 		# Une chaîne mtg ou mtgoi. 23/12/2022.
# 		log_info "ajout de 10 minutes pour se caler sur l'imagerie std : deltat ${YYYYMMDD}${HH}${MIN} + 10 mn"
# 		dateImagerie=`deltat ${YYYYMMDD}${HH}${MIN} + 10 mn`
# 		test_exit $? "deltat"
# 		YYYY=${dateImagerie:0:4}
# 		MM=${dateImagerie:4:2}
# 		DD=${dateImagerie:6:2}
# 		HH=${dateImagerie:8:2}
# 		MIN=${dateImagerie:10:2}
# 	fi

# 	VAL_K_time="${YYYY}-${MM}-${DD}T${HH}:${MIN}:${SS}Z"

# 	SEG_1="<Metadata><MDI key=\"TIFFTAG_IMAGEDESCRIPTION\">{\"process\":\"${VAL_K_process}\",\"aggregate\":\"${VAL_K_aggregate}\", \"time\":\"${VAL_K_time}\"}</MDI></Metadata>"
# 	VRT_MODIF="`echo $VRT|cut -d"." -f1`.new.vrt"
# 	echo "${SEG_0}" >	$VRT_MODIF
# 	echo "${SEG_1}" >> $VRT_MODIF
# 	echo "${SEG_2}" >> $VRT_MODIF
# 	FILE_OUT="`echo $FILE_IN`.TAG"

# 	log_info "gdal_translate -q -of gtiff -co \"COMPRESS=LZW\"$VRT_MODIF $FILE_OUT"
# 	gdal_translate -q -of gtiff -co "COMPRESS=LZW" $VRT_MODIF $FILE_OUT
# 	# -of gtiff rajouté le 4/5/2021 pour gdal3.
# 	test_exit $? "gdal_translate"
# 	teste_fichier_present ${FILE_OUT}

# 	rm ${VRT_MODIF} ${VRT}
# 	test_exit $? "rm"
# 	} # app_add_Tag()


#==============================================================================
# main 
#==============================================================================

#------------------------------------------------------------------------------
# chargement standard
#
. liblog.sh
#------------------------------------------------------------------------------


log_info $*

# recuperation des options

while getopts P:S:s:d:h:n: c ; do
	case $c in
		S)	SRCID=$OPTARG
			;;
		P)	PRDID=$OPTARG
			;;
		s)	SATIMG=$OPTARG
			;;
		d)	YYYYMMDD=$OPTARG
			;;
		h)	HHMN=$OPTARG
			;;
		n)	NNNNN=$OPTARG
			;;

		\?)	app_exit 1 "erreur syntaxe : option non reconnue"
			;;
	esac
done

shift `expr $OPTIND - 1`

if [ $# -ne 2 ]; then #fichier_source fichier_produit
	app_exit 1 "erreur syntaxe : nombre d'arguments incorrect"
fi

FILE_SRC=$1
shift
FILE_PRD=$1
#controle source
#if [ \( "$ARCHIPEL_ID" = 'msg' \) -o \( "$ARCHIPEL_ID" = 'msgbis' \) -o \( "$ARCHIPEL_ID" = 'mtg' \) ] ; then
if [ ! -z $(echo $ARCHIPEL_ROOT|grep msg) ]; then
	SRC_OK=globeMIceCrystRiskGT
elif [ \( "$ARCHIPEL_ID" = 'msgoi' \) -o \( "$ARCHIPEL_ID" = 'msgoibis' \) ]; then
	SRC_OK=globeIIceCrystRiskGT
elif [ \( "$ARCHIPEL_ID" = 'goeseast' \) -o \( "$ARCHIPEL_ID" = 'goeseastbis' \) ]; then
	SRC_OK=globeEIceCrystRiskGT
elif [ \( "$ARCHIPEL_ID" = 'goeswest' \) -o \( "$ARCHIPEL_ID" = 'goeswestbis' \) ]; then
	SRC_OK=globeWIceCrystRiskGT
elif [ \( "$ARCHIPEL_ID" = 'hima' \) -o \( "$ARCHIPEL_ID" = 'himabis' \) ]; then
	SRC_OK=globeJIceCrystRiskGT
fi

case $SRCID in
	${SRC_OK})
		log_info "source $SRCID";;
	*)	log_info "source invalide : $SRCID"
		app_exit 1;;
esac

# log_info "ls SPOOL :"
# ls SPOOL
log_info "ls WRK_SRC :"
ls -l WRK_SRC

# globeMhiwcMaskNC_msg04_20190724_1245_00026
#log_info "fabrication du produit Ice Water Content mask au format geotiff : makeIWCgeotiff.py -ncfile ${FILE_SRC} -out ${FILE_PRD}"
#makeIWCgeotiff.py -ncfile ${FILE_SRC} -out ${FILE_PRD}
#test_exit $? "check appel makeIWCgeotiff.py"
#teste_fichier_present ${FILE_PRD}
# exemple de syntaxe du fichier d'entrée (variable FILE_SRC) : globeMIceCrystRiskGT_msg03_20230523_1230_00025_imgICRisk_0
log_info "reprojection iso lat - iso lon : "
log_info "gdalwarp -t_srs epsg:4326 ${FILE_SRC} \"${FILE_SRC}.iso_ll.tif\" 2>/dev/null"
gdalwarp -t_srs epsg:4326 ${FILE_SRC} ${FILE_SRC}.iso_ll.tif 2>/dev/null
#
log_info "coloration de l'image"
log_info "GTiffModifColorTable.py -f \"${FILE_SRC}.iso_ll.tif\" -ct config/ct_icRisk.new.txt -o \"${FILE_SRC}.color.tif\""
GTiffModifColorTable.py -f ${FILE_SRC}.iso_ll.tif -ct config/ct_icRisk.new.txt -o ${FILE_SRC}.color.tif
#
log_info "Expansion du tif avec palette en image RGBA"
log_info "gdal_translate -expand rgba \"${FILE_SRC}.color.tif\" \"${FILE_SRC}.rgba.tif\""
gdal_translate -expand rgba ${FILE_SRC}.color.tif ${FILE_SRC}.rgba.tif
#
log_info "Mise en transparence de la bande alpha du produit" 
log_info "convert ${FILE_SRC}.rgba.tif -alpha On -channel Alpha -evaluate set 90% ${FILE_SRC}.transp90.tif"
convert ${FILE_SRC}.rgba.tif -alpha On -channel Alpha -evaluate set 90% ${FILE_SRC}.transp90.tif
#
log_info "Superposition du produit et d'un fond de carte"
log_info "composite ${FILE_SRC}.transp90.tif config/fond.countries.OK.tif -compose Multiply ${FILE_SRC}.superpos.tif"
composite ${FILE_SRC}.transp90.tif config/fond.countries.OK.tif -compose Multiply ${FILE_SRC}.superpos.tif
#
log_info "Ajout du georeferencement"
log_info "gdal_translate -a_srs epsg:4326 -a_ullr -81.2766364 74.1685451 81.2704036 -74.0472013 ${FILE_SRC}.superpos.tif ${FILE_SRC}.superpos.epsg4326.tif"
gdal_translate -a_srs epsg:4326 -a_ullr -81.2766364 74.1685451 81.2704036 -74.0472013 ${FILE_SRC}.superpos.tif ${FILE_SRC}.superpos.epsg4326.tif
#
log_info "Ajout du shapefile countries_lines"
log_info "gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 200 -l countries_lines config/countries_lines.shp ${FILE_SRC}.superpos.epsg4326.tif"
gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 200 -l countries_lines config/countries_lines.shp ${FILE_SRC}.superpos.epsg4326.tif
#
log_info "Ajout de la couche des FIR aero"
log_info "gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 150 -l FirUir_NM config/FirUir_NM.json ${FILE_SRC}.superpos.epsg4326.tif"
gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 150 -l FirUir_NM config/FirUir_NM.json ${FILE_SRC}.superpos.epsg4326.tif
#
log_info "Compression de l'image"
log_info "gdal_translate -co compress=lzw ${FILE_SRC}.superpos.epsg4326.tif ${FILE_SRC}.superpos.lzw.tif"
gdal_translate -co compress=lzw ${FILE_SRC}.superpos.epsg4326.tif ${FILE_SRC}.superpos.lzw.tif
#
teste_fichier_present ${FILE_SRC}.superpos.lzw.tif
log_info "move ${FILE_SRC}.superpos.lzw.tif ${FILE_PRD}"
mv ${FILE_SRC}.superpos.lzw.tif ${FILE_PRD}
#
log_info "nettoyage de fichiers temporaires"
rm -f ${FILE_SRC}.superpos.epsg4326.tif
rm -f ${FILE_SRC}.superpos.tif
rm -f ${FILE_SRC}.transp90.tif
rm -f ${FILE_SRC}.rgba.tif
rm -f ${FILE_SRC}.color.tif
rm -f ${FILE_SRC}.iso_ll.tif
#
log_info "ls WRK_PRD:"
ls -l WRK_PRD
log_info "ls WRK_SRC :"
ls -l WRK_SRC		
log_info "contenu du répertoire courant : "
ls -l
#
app_exit 0
# fin de traitement
#==============================================================================
# (C) METEO-FRANCE
#==============================================================================