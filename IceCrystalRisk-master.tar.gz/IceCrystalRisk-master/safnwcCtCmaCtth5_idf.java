/*#! 
!
! @(#)safnwcCtCmaCtth5_idf.java version du 13/12/2022.
!
!++
! NOM
!	safnwcCtCmaCtth5_idf
! SOMMAIRE
!	Pour les sources en hdf5 CTh5 (cloud type), CMah5 (cloud mask)
!		et CTTh5 (temperature ou pression au sommet des nuages),
!	sortir le nom du satellite, les dates et heures et numero de slot.
!
!	Appelé dans l'identification des sources CMah5, CTh5 et CTTh5 (les produits du saf)
!	dans la réception safnwc des chaînes msg et goeseast.
!	
!	Destiné à fabriquer le produit pour les modèles.
!
! DOMAINE D'INTÉGRATION.
!	cms
! SYNTAXE
!	java safnwcCtCmaCtth5_idf S_NWC_CTTH_MSG3_euratr-VISIR_20220304T000000Z.nc
!
! COMPILATION.
!	javac safnwcCtCmaCtth5_idf.java -encoding iso-8859-1
! AUTEUR.
!	laurent périer.
! VERSION.
!	21/10/2014 :	création.
!	30/1/2017 :	un nouvel attribut global dans le fichier netcdf du saf. Les deux attributs sont testés.
!	12/2/2019 :	rajout des GOES 16 et 17.
!	23/3/2019 :	retour au code avec la fonction AttributPresent(), sinon, le programme s'arrête dans 
!			la classe NetcdfGlobalAttributes.java pour le traitement de msg.
! 	23/09/2020 :	retour arriere (v 23/3/2019) apres une adaptation suite a un pb de datation sur produit cristaux de glace.
!	4/3/2022 :	le choix du numéro de cycle nnnnn est conforme à hhmn2slot.c pour les msgs. Cette modification
!			est nécessaire pour arôme sur msgrs.
!	19/10/2022 :	goes18 est rajouté.
!	13/12/2022 :	hima09 rajouté.
!
*/

import java.io.*;
import java.util.*;
import java.lang.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class safnwcCtCmaCtth5_idf
	{
	static Logger	logger = LoggerFactory.getLogger(safnwcCtCmaCtth5_idf.class);

	public static void main(String[] args)
		{
		// logger.info("Arguments = " + args[0] + " " + args[args.length - 1] + " nb = " + args.length);
		// java safnwcCtCmaCtth5_idf -i SAFNWC_MSG3_CMa__201402051400_globeM______.h5.penhir

		// Lecture des arguments
		String	fileName = args[args.length - 1];
			// SAFNWC_MSG3_CMa__201402051400_globeM______.h5.penhir
			// SAFNWC_MSG3_CTTH_201402051400_globeM______.h5.penhir
			// SAFNWC_MSG3_CT___201402051400_globeM______.h5.penhir

			// A l'exécution dans l'application, le nom change :
			// CMah5_msg03_20140205_140000_00028_safncm_0.penhir

		// logger.info("fileName = " + fileName);
		// Analyse du nom du fichier (identification syntaxique)

		String	satimg = "erreur";

		if ((fileName.contains("MSG4")) || (fileName.contains("msg04")))		satimg = "msg04";
		else if ((fileName.contains("MSG3")) || (fileName.contains("msg03")))		satimg = "msg03";
		else if ((fileName.contains("MSG2")) || (fileName.contains("msg02")))		satimg = "msg02";
		else if ((fileName.contains("MSG1")) || (fileName.contains("msg01")))		satimg = "msg01";
		else if ((fileName.contains("GOES16")) || (fileName.contains("goes16")))	satimg = "goes16";
		else if ((fileName.contains("GOES17")) || (fileName.contains("goes17")))	satimg = "goes17";
		else if ((fileName.contains("GOES18")) || (fileName.contains("goes18")))	satimg = "goes18";
		else if ((fileName.contains("HIMA08")) || (fileName.contains("hima08")))	satimg = "hima08";
		else if ((fileName.contains("HIMA09")) || (fileName.contains("hima09")))	satimg = "hima09";
		else
			{
			logger.error("Ni MSGn, ni GOES trouves. " + fileName);
			System.exit(1);
			}

		// Chargement des attributs globaux du fichier hdf5.
		NetcdfGlobalAttributes	nga = new NetcdfGlobalAttributes(fileName);

		String	yyyymmdd, hhmn;
		String	yyyymmddhhmn = "";

		// Valeur de l'attribut global recherché.
		boolean	attributtrouve = nga.AttributPresent("IMAGE_ACQUISITION_TIME");
		if (attributtrouve)
			{
			try
				{
				yyyymmddhhmn = nga.getAttribute("IMAGE_ACQUISITION_TIME");
				}
			catch (Exception e)
				{
				logger.error("Attr IMAGE_ACQUISITION_TIME trouve puis non extrait.");
				System.exit(1);
				}

			yyyymmdd = yyyymmddhhmn.substring(0, 8);
			hhmn = yyyymmddhhmn.substring(8, 12);
			}
		else
			{
			attributtrouve = nga.AttributPresent("nominal_product_time");
			if (! attributtrouve)
				{
				logger.error("Attr IMAGE_ACQUISITION_TIME non trouve. nominal_product_time non trouve \n");
				System.exit(1);
				}

			// Rajout du 30/1/2017 pour les fichiers en netcdf sortant du saf.
			try
				{
				yyyymmddhhmn = nga.getAttribute("nominal_product_time");
				// 2017-01-30T14:15:00Z
				}
			catch (Exception e)
				{
				logger.error("Attr nominal_product_time trouve puis non extrait.");
				System.exit(1);
				}

			yyyymmdd = yyyymmddhhmn.substring(0, 4) + yyyymmddhhmn.substring(5, 7) + yyyymmddhhmn.substring(8, 10);
			hhmn = yyyymmddhhmn.substring(11, 13) + yyyymmddhhmn.substring(14, 16);
			}

		int	hourFile = Integer.parseInt(hhmn.substring(0, 2));
		int	minFile = Integer.parseInt(hhmn.substring(2, 4));

		int	numslot;
		if (satimg.contains("msg"))
			{
			// Nouveauté du 4/3/2022. Cette modification est nécessaire pour arôme sur msgrs.
			// Nous nous conformons à hhmn2slot.c utilisé dans XRITfile_idf.pl appelé
			// dans l'identification des segments concaténés dans les chaînes msg.
			float	hj = hourFile + (float)minFile / 60.f;
			numslot = (int)Math.ceil(hj * 2.);
			}
		else
			{
			numslot = hourFile * 2;
			if (minFile >= 30)
				numslot += 1;
			// Conforme à ABInc_idf.py pour les goesr.
			// Conforme à GranulesNCMtgIdf.
			// Conforme à SegmentHimawariIdf.
			}

		// Enlevé le 4/3/2022 depuis le rajout ci-dessus.
		// if (minFile >= 15)	numslot ++;	// Dans la chaîne MSG, 15' et 30' ont le même numéro.
		// if (minFile >= 45)	numslot ++;	// Dans la chaîne MSG, 45' et 0' de l'heure suivante ont le même numéro.

		if (numslot == 0)	numslot = 48;

		String	nnnnn = Integer.toString(numslot);

		if (nnnnn.length() == 1) nnnnn = "0000" + nnnnn; // nnnnn must be 5 character length
		if (nnnnn.length() == 2) nnnnn = "000" + nnnnn;
		if (nnnnn.length() == 3) nnnnn = "00" + nnnnn;

		if ((numslot > 0) && (numslot <= 48))
			System.out.println(satimg + " " + yyyymmdd + " " + hhmn + " " + nnnnn);
		// Sinon, on suppose que le nom du fichier ne respecte pas les exemples ci-dessus.

		} // fin du main

	} // fin de la classe.

