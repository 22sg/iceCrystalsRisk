#!/bin/sh
if [ -z $1 ]; then
   echo "missing globe Ice Cryst Risk Product"
   exit 1
else
   prdFile=$1
fi
#
WRKDIR=/home/mcms/guevels/IceCrystals_20230501
# copie locale : 
cp $prdFile ${WRKDIR}/tmp/
prdName=$(basename $prdFile)
prdName=${WRKDIR}/tmp/${prdName}
echo "reprojection eq cyl : "
#gdalwarp -t_srs epsg:4326 globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.tif globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.iso_latlon.tif
gdalwarp -t_srs epsg:4326 $prdName ${prdName/.tif/.iso_ll.tif} 2>/dev/null
#
echo "coloration de l'image"
GTiffModifColorTable.py -f ${prdName/.tif/.iso_ll.tif} -ct ${WRKDIR}/ct_icRisk.new.txt -o ${prdName/.tif/.iso_ll.color.tif}
#
echo "expand tif with ct in RGBA tif"
gdal_translate -expand rgba ${prdName/.tif/.iso_ll.color.tif} ${prdName/.tif/.iso_ll.rgba.tif}  #globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.iso_latlon.tif globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.iso_latlon.rgb.tif
#convert globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.iso_latlon.rgba.tif -alpha On -channel Alpha -evaluate set 90% globeMIceCrystRiskGT_msg03_20230525_1200_kermorvan220x.iso_latlon.transp90.tif
echo "mise en transparence de la bande alpha du produit" 
convert ${prdName/.tif/.iso_ll.rgba.tif} -alpha On -channel Alpha -evaluate set 90% ${prdName/.tif/.iso_ll.transp90.tif}
#
echo "superposition du produit et d'un fond de carte"
composite ${prdName/.tif/.iso_ll.transp90.tif} ${WRKDIR}/fonds/fond.countries.OK.tif -compose Multiply ${prdName/.tif/.iso_ll.superpos.tif}
#
echo "ajout du georeferencement"
gdal_translate -of gtiff -a_srs epsg:4326 -a_ullr -81.2766364 74.1685451 81.2704036 -74.0472013 ${prdName/.tif/.iso_ll.superpos.tif} ${prdName/.tif/.iso_ll.superpos.gtif}
#
echo "ajout du shapefile countries_lines"
gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 200 -l countries_lines ${WRKDIR}/shapefiles/countries_lines.shp ${prdName/.tif/.iso_ll.superpos.gtif}
#
echo "ajout de la couche des FIR aero"
gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 150 -l FirUir_NM ${WRKDIR}/shapefiles/FirUir_NM.json ${prdName/.tif/.iso_ll.superpos.gtif}
#
#echo "ajout de la couche des continents"
#gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 100 -burn 200 -l gshhs_land /espaceL/users/bachevillerf/shapefiles/gshhs_land.shp ${prdName/.tif/.iso_ll.rgb.tif}
#
#echo "ajout de la couche des FIR aero"
#gdal_rasterize -b 1 -b 2 -b 3 -burn 50 -burn 200 -burn 100 -l FirUir_NM ${WRKDIR}/shapefiles/output.json ${prdName/.tif/.iso_ll.rgb.tif}
#
echo "compression de l'image"
gdal_translate -co compress=lzw ${prdName/.tif/.iso_ll.superpos.gtif} ${prdName/.tif/.iso_ll.rgb.lzw.tif}
#
echo "nettoyage de fichiers temporaires"
rm $prdName ${prdName/.tif/.iso_ll.tif} ${prdName/.tif/.iso_ll.superpos.tif} ${prdName/.tif/.iso_ll.superpos.gtif} ${prdName/.tif/.iso_ll.rgba.tif} ${prdName/.tif/.iso_ll.transp90.tif} ${prdName/.tif/.iso_ll.color.tif} 
#
echo "deplacement de l'image"
mv ${prdName/.tif/.iso_ll.rgb.lzw.tif} ${prdName/globeMIceCrystRiskGT/globeMIceCrystRiskFondsGT}
#



#ls -rtl
#ls -rtl ${WRKDIR}/tmp/
exit 0
# fin traitements.
