#!/bin/bash

#environnement

SAT="msg2"
BDPE=15081
source /opt/metwork-mfext-2.0/share/profile
domaineMachine=`cat /usr/local/sopra/etc/domaine_machine.txt`

case $domaineMachine  in
    "int" )
    echo "integration"
    ;;
     "oper" )
    echo "opérationnel"
    ;;
    "dev")
    echo "developpement"
        echo "serveur developpement"
        export DMT_PATH_EXEC="$(pwd)/.."
        DMT_DATE_PIVOT=$1
        DMT_ECHEANCE="000000"
        export HOME_RO="$(pwd)/../RO/"
        # pre nettoyage expe precedente
        rm -f *tiff
        rm -f SA.*
        rm -f out.grb
        rm -f *.png
    ;;
    *)
    echo "inconnue"
    ;;
esac

. importf_ro template.grb


set -x
python ${DMT_PATH_EXEC}/LIB/make_icemask.py $SAT ${DMT_DATE_PIVOT}
RETURNCODE=$?
set +x

if [ ${RETURNCODE} -ne 0 ]
then
    echo "${DMT_PATH_EXEC}/LIB/make_icemask.py $SAT ${DMT_DATE_PIVOT} est sortie en erreur, code_retour=${RETURNCODE}"
    exit ${RETURNCODE}
fi

FILENAME=${SAT}_${DMT_DATE_PIVOT}_${DMT_ECHEANCE}.grb
mv out.grb ${FILENAME}
if [ -s ${FILENAME} ]
then
    router_pe $PWD/${FILENAME} BDPE+FTP_SYNOPSIS -p previaero -n ${BDPE} -e 000000 -d $DMT_DATE_PIVOT -q 0
else
    echo "${FILENAME} absent, pas de routage"

fi

# nettoyage
if [ ${domaineMachine} == "dev" ]
then
    rm -f *.nc
#    rm -f *tiff
    rm -f rdt*.tar
    rm -f rdt*.tar.diag
#    rm -f dir_SATELLITE
    rm -f S_NWC_CTRAJ*
fi

