#!/bin/bash
# On definit les fichiers a extraire sur la BDI et les noms des fichiers associés
SAT=$1
date_pivot=$2
nom_champ=$3

echo $SAT
echo $date_pivot
echo $nom_champ

if [ $nom_champ = "IWC_NWC" ]
then
format=GEOTIFF
case $SAT in
    MSG4 ) producteur=MSGC;
          nom_vue=V_SPACE-0
       ;;
    MSG3 ) producteur=MSGC;
          nom_vue=V_SPACE-0
       ;;
    MSG2 ) producteur=MSGC;
          nom_vue=V_SPACE-455E
       ;;
    MSG1 ) producteur=MSGC;
          nom_vue=V_SPACE-415E
       ;;
    GOES18 ) producteur=GOES;
          nom_vue=V_SPACE-137W
        ;;
    GOES17 ) producteur=GOES;
          nom_vue=V_SPACE-137W
        ;;
    GOES16 ) producteur=GOES;
          nom_vue=V_SPACE-75W_G
         ;;
    HIMA09 ) producteur=GMS;
          nom_vue=V_SPACE-141E
         ;;
    HIMA08 ) producteur=GMS;
          nom_vue=V_SPACE-141E
         ;;
    * ) echo " $filename : Not processed"
       ;;
esac
fi

if [  $nom_champ = "CN_NWC" ]
then
case $SAT in
    MSG4 ) producteur=MSGC
          nom_vue=V_GLOBE-00
          format=TIFF
       ;;
    MSG3 ) producteur=MSGC
          nom_vue=V_GLOBE-00
          format=TIFF
       ;;
    MSG2 ) producteur=MSGC
          nom_vue=V_SPACE-455E2
          format=TIFF
       ;;
    MSG1 ) producteur=MSGC
          nom_vue=V_SPACE-415E
          format=TIFF
       ;;
    GOES18 ) producteur=GOES
          nom_vue=V_SPACE-137W
          format=GEOTIFF
        ;;
    GOES17 ) producteur=GOES
          nom_vue=V_SPACE-137W
          format=GEOTIFF
        ;;
    GOES16 ) producteur=GOES
          nom_vue=V_SPACE-75W_G
          format=GEOTIFF
         ;;
    HIMA09 ) producteur=GMS
          nom_vue=V_GLOBEJ
          format=TIFF
         ;;
    HIMA08 ) producteur=GMS
          nom_vue=V_GLOBEJ
          format=TIFF
         ;;
    * ) echo " $filename : Not processed"
       ;;
esac
fi


# Requete
cat <<EOF > dir_SATELLITE
type_produit_id:SA
type_production_id:OBS
producteur_gene_id:${producteur}
nom_vue_id:${nom_vue}
param_id:${nom_champ}
format_id:${format}
gzip:N
info:N
min_dat_reseau:${date_pivot}
max_dat_reseau:${date_pivot}
min_dat_validite:${date_pivot}
max_dat_validite:${date_pivot}
bstr:O
EOF


domaineMachine=$(cat /usr/local/sopra/etc/domaine_machine.txt)
if [ "$domaineMachine" == "int" ];then
export DB_FILE_BDI=/usr/local/sopra/neons_db_bdi.intgr
fi
RdImage -fdir_SATELLITE


mv SA.${producteur}.${nom_vue}.${nom_champ}__${date_pivot} ${nom_champ}.tiff

