# coding: utf-8

###########################################################################################################
# Calcule le produit ICEMASK. Détection des cristaux de glace 
# Il est base sur la combinaison des traces de RDT (profondeur 2H) dans le temps + masque sat CPP (jour)
# ou classif nuageuse nuages hauts/très hauts (nuit)
# auteur : pierre.crispel@meteo.fr
#
# Les fichiers de sortie sont au format grib2 domaine GLOBE (0125 ou 025)
#
# En entree 
#       le fichier RDT au format netcdf
#       le fichier CPP au format geotiff
#       le fichier CLASSIF_NUAGEUSE au format tiff ou geotiff suivant les sat
# 
############################################################################################################

import numpy as np
from datetime import datetime,timedelta
import sys,os
from netCDF4 import Dataset
from osgeo import gdal
import pyproj
from scipy import ndimage
import matplotlib
from matplotlib.path import Path
from glob import glob

from utils import *
from meta_data import *


####################################
#PARAMETRES EN ENTREE DU PROGRAMME
####################################

sat = sys.argv[1]
datepivot=sys.argv[2]


plot=False
#plot=True
#sat="goes16"
#datepivot="20211103223000"



date=datepivot[0:8]
heure=datepivot[8:12]

# constantes :
res_glob=0.125
Nlats_glob=int(180/res_glob)+1
Nlons_glob=int(360/res_glob)
tmax=120 #  integration RDT sur 120 minutes

fname_out_png='ICEMASK_%s_%s_GLOB%s.png'%(sat,datepivot,str(res_glob).replace('.',''))
fname_out_grb="out.grb"
fname_template_grb='template.grb'



# liste des zones rdt suivant le satellite (issues des metadonnees)
lst_zones_rdt=[]
for zone in dict_rdt.keys():
    if dict_rdt[zone]['sat']==sat:
        lst_zones_rdt.append(zone)


###########################################################
#EXTRACTION FICHIERS SAT (ICE CRYSTALS + CLASSE NUAGE)
##########################################################"

fileinCPP='IWC_NWC.tiff'
fileinCN='CN_NWC.tiff'

extraction_bdi = '/'.join([os.environ["DMT_PATH_EXEC"],'LIB','extraction_donnees_SAT-BDI.sh'])

os.system("bash %s %s %s %s "%(extraction_bdi, sat.upper(),datepivot,"IWC_NWC"))
os.system("bash %s %s %s %s "%(extraction_bdi, sat.upper(),datepivot,"CN_NWC"))


#####################################################
## calcul masque CPP 
#####################################################
# Lecture CPP : Masque CPP : 255 et 1 --> 1, le reste --> 0
# 0  extérieur cercle 
# 1 pas de nuage ou nuit
# 254 nuage non glace
# 255 glace

print("calcul masque CPP")

ds=gdal.Open(fileinCPP, gdal.GA_ReadOnly)   


width = ds.RasterXSize
height = ds.RasterYSize
gt=ds.GetGeoTransform()

ulx = gt[0]
uly = gt[3]
lrx = gt[0]+ width*gt[1]
lry = gt[3]+ height*gt[5]

# pour accelerer les calculs sous echantillonnage de
# l image au pas satstep
satstep=1
if (width>=22000 and height>=22000):
    satstep=8
elif (width>=11000 and height>=11000):
    satstep=4
elif (width>=5400 and height>=5400):
    satstep=2


print(width,satstep)

cms=ds.ReadAsArray()[::satstep,::satstep].ravel()

x=np.linspace(ulx,lrx,width,endpoint=True)[::satstep]
y=np.linspace(uly,lry,height,endpoint=True)[::satstep]
x,y= np.meshgrid(x,y)

p_cpp=pyproj.Proj(dict_sat[sat]['projection'])

lons_cpp, lats_cpp = p_cpp(x, y, inverse=True)
lons_cpp=lons_cpp.ravel()
lats_cpp=lats_cpp.ravel()

# on recupere les lats et lons --> on transforme les lats,lons negatives en [0:360[
lons_cpp[lons_cpp<0]=lons_cpp[lons_cpp<0]+360


#####################################################
## calcul masque Classe Nuageuse en gtiff ou tiff
#####################################################

# Lecture CN :
# 0  extérieur cercle 
# 12--> 14 nuages hauts

print("calcul masque Classe Nuageuse")

if os.path.isfile(fileinCN):
    dscn=gdal.Open(fileinCN, gdal.GA_ReadOnly)   

    width = dscn.RasterXSize
    height = dscn.RasterYSize
    #on lit les infos dans dict_satSA.GOES.V_SPACE-75W_G.CN_NWC__20210906130000


    ulx = float(dict_sat[sat]['ulx'])
    uly = float(dict_sat[sat]['uly'])
    lry = float(dict_sat[sat]['lry'] )
    lrx = float(dict_sat[sat]['lrx'])

    # pour accelerer les calculs sous echantillonnage de
    # l image au pas satstep

    satstep=1
    if (width>=22000 and height>=22000):
        satstep=8
    elif (width>=11000 and height>=11000):
        satstep=4
    elif (width>=5400 and height>=5400):
        satstep=2

    print(width,satstep)

    cn=dscn.ReadAsArray()[::satstep,::satstep].ravel()

    cn[(cn<11)|(cn>14)]=0
    cn[(cn>=11)&(cn<=14)]=1

    x=np.linspace(ulx,lrx,width,endpoint=True)[::satstep]
    y=np.linspace(uly,lry,height,endpoint=True)[::satstep]
    x,y= np.meshgrid(x,y)

    pcn=pyproj.Proj(dict_sat[sat]['projection'])
    lons_cn, lats_cn = pcn(x, y, inverse=True)
    lons_cn=lons_cn.ravel()
    lats_cn=lats_cn.ravel()

    # on recupere les lats et lons --> on transforme les lats,lons negatives en [0:360[
    lons_cn[lons_cn<0]=lons_cn[lons_cn<0]+360



########################################
#### BOUCLE POUR CHAQUE ZONE RDT  ######
########################################

# def constante liste de dates

datef=datetime.strptime(datepivot,"%Y%m%d%H%M%S")
a=[datef-timedelta(minutes=i) for i in range(0,120+dict_sat[sat]['freq'],dict_sat[sat]['freq'])]
lst_dates=[datetime.strftime(val,"%Y%m%dT%H%M%SZ") for val in a]
ndates=len(lst_dates)

print(lst_dates)
for nz,zone in enumerate(lst_zones_rdt):
    print(" ")
    print("zone : ",zone)
    print(" ")
    bdpe=dict_rdt[zone]["bdpe"]
    tab={}
    k_absents=[]
    traitement_rdt_latlon=False

    #############################################
    # Acquisition liste RDT dans dict. tab
    ###########################################

    for k,d in enumerate(lst_dates):
        print(k,d)
        date_bdpe=d.replace('T','').replace('Z','')
        os.system("lirepe %s %s %s %s "%(bdpe,date_bdpe,'000000',"rdt.tar"))
        os.system("tar -xvf rdt.tar ")

        ## gestion de l absence d'une date
        try:
            print(glob("*%s*%s.nc"%(dict_rdt[zone]['zone_nc'],d)))
            fin_rdt=glob("*%s*%s.nc"%(dict_rdt[zone]['zone_nc'],d))[0]
            rdt=Dataset(fin_rdt)
        except:
            k_absents.append(k)
            print("date %s absente"%d)
            # on s'autorise a avoir 1 fichier sur 5 manquants
            if len(k_absents)/len(lst_dates)<0.21:
                continue
            else:
                print(" tar RDT incomplet pour différentes échéances --> impossible de calculer la trace RDT --> on stoppe l execuction avec le code 99")
                sys.exit(99)

        ## extraction des donnees lat/lon presentes dans le rdt (uniquement au premier passage)
        if not(traitement_rdt_latlon):
            p=pyproj.Proj(rdt.gdal_projection)  # DeprecationWarning sur centOS8

            dx=abs(rdt.variables['nx'][:].data[1]-rdt.variables['nx'][:].data[0])  # DeprecationWarning sur centOS8

            # ss echantillonnage
            rdt_step=1
            if abs(dx)<2500:
                rdt_step=2
            print("rdt :facteur ss echantillonnage : %s"%rdt_step)

            # tableaux de coordonnees x,y
            x_rdt, y_rdt = np.meshgrid(rdt.variables['nx'][:].data[::rdt_step], rdt.variables['ny'][:].data[::rdt_step])  # DeprecationWarning sur centOS8
            # projection en lat,lon
            lons_rdt, lats_rdt = p(x_rdt, y_rdt, inverse=True)
            lons_rdt=lons_rdt.ravel()
            lats_rdt=lats_rdt.ravel()

            # index des lat/lon rdt sur le globe (elimine les projections hors globe)
            s1=set(np.where((-180<lons_rdt)&(lons_rdt<=180))[0])
            s2=set(np.where((-90<lats_rdt)&(lats_rdt<90))[0])
            ixs_rdt=list(s1.intersection(s2))
            traitement_rdt_latlon=True   

        tab[k]=rdt.variables['MapCellCatType'][:].data [::rdt_step,::rdt_step].ravel()  # DeprecationWarning sur centOS8
        # on efface les fichiers traites
        print("traitement %s OK"%fin_rdt)
        os.system("rm -f %s"%fin_rdt)
        os.system("rm -f rdt.tar ")

    ###############################################################################
    ##### Calcul de la trace + risque RDT sur X minutes passees 
    #####  & PROJECTION SUR GRILLE GLOB
    ##############################################################################
    print(" de la trace + risque RDT")
    
    maskrdt=False #trace de la cellule  
    maskovs=False #la trace de la cellule avec la categorie overshoot=finalovs
    maskdecay=False     #la trace de la cellule avec la categorie decroissance=finaldecay
    maskprecip=False      #la trace de la cellule avec la categorie fort taux de precipitation (non utilise)

    # operations sur des booleens
    print (set(range(0,ndates))-set(k_absents))
    for k in set(range(0,ndates))-set(k_absents):
        maskrdt=maskrdt+((tab[k]>0) & (tab[k]<22))        
        maskovs=maskovs+(tab[k]==5) 
        maskdecay=maskdecay+(tab[k]==6) + (tab[k]==11)+ (tab[k]==16)+(tab[k]==21)
        maskprecip=maskprecip+(tab[k]==15) + (tab[k]==16)

    maskrdt=maskrdt.astype(int)
    maskovs=maskovs.astype(int)
    maskdecay=maskdecay.astype(int)
    maskprecip=maskprecip.astype(int)

    #la trace de la cellule en fonction des categorie finalcellule + on regroupe les classes 3 et 4 --> 3
    ice_crystals_risk_rdt=maskrdt+2*maskovs+maskdecay
    ice_crystals_risk_rdt[ice_crystals_risk_rdt==4]=3

    # reprojection en lat_lon sur grille glob - on convertit en les longitudes en [0,360[
    lons_rdt[lons_rdt<0]=lons_rdt[lons_rdt<0]+360

    # calcul index sur grille GLOB0125 [0-360[ pour latitudes + gestion periodicite
    j_rdt,i_rdt=index_in_glob(lats_rdt[ixs_rdt],lons_rdt[ixs_rdt],res=0.125)
    i_rdt[i_rdt==Nlons_glob]=0
    i_rdt[i_rdt==-1]=Nlons_glob-1

    ice_crystals_risk_rdt_glob=np.ones((Nlats_glob,Nlons_glob),dtype=int)*-1
    ice_crystals_risk_rdt_glob[j_rdt,i_rdt]=ice_crystals_risk_rdt[ixs_rdt]

    # on étend le domaine ciblé par la trace rdt pour inclure les enclumes (~100 km)
    ice_crystals_risk_rdt_glob=ndimage.maximum_filter(ice_crystals_risk_rdt_glob,size=9)
    ice_crystals_risk_rdt_glob[ice_crystals_risk_rdt_glob==-1]=9999

    #########################################################################
    #### PROJECTION PRODUIT CMS RESTREINT A ZONE RDT SUR GLOB ##############
    #######################################################################

    # filtre des lats_lons concernees pour la zone RDT
    s0=set(np.where(cms!=0)[0])
    if abs((max(lons_rdt[ixs_rdt])-min(lons_rdt[ixs_rdt]))-360)>0.125:
        s1=set(np.where((min(lons_rdt[ixs_rdt])<lons_cpp) & (lons_cpp<max(lons_rdt[ixs_rdt])))[0])
        s2=set(np.where((min(lats_rdt[ixs_rdt])<lats_cpp) & (lats_cpp<max(lats_rdt[ixs_rdt])))[0])
    else:
        # on coupe le meridien 0
        lons_tmp=lons_rdt[ixs_rdt].copy()
        lons_tmp[lons_tmp>=180]=lons_tmp[lons_tmp>=180]-360
        mn,mx=min(lons_tmp)+360,max(lons_tmp)
        s1=set(np.where(((0<=lons_cpp) & (lons_cpp<mx)) | ((lons_cpp>mn) & (lons_cpp<360)))[0])
        s2=set(np.where((min(lats_rdt[ixs_rdt])<lats_cpp) & (lats_cpp<max(lats_rdt[ixs_rdt])))[0])

    ixs_cpp=list(s0.intersection(s1).intersection(s2))

    # calcul index sur grille GLOB0125 [0-360[ pour latitudes
    j_cpp,i_cpp=index_in_glob(lats_cpp[ixs_cpp],lons_cpp[ixs_cpp],res=0.125)
    i_cpp[i_cpp==Nlons_glob]=0
    i_cpp[i_cpp==-1]=Nlons_glob-1

    ice_crystals_cms_glob=np.ones((Nlats_glob,Nlons_glob),dtype=int)*9999
    ice_crystals_cms_glob[j_cpp,i_cpp]=cms[ixs_cpp]

    ########################################################################
    ################# PROJECTION CN RESTREINT A ZONE RDT SUR GLOB ##########
    ########################################################################

    if not(os.path.isfile(fileinCN)):
        ice_crystals_cn_glob=np.ones(ice_crystals_cms_glob.shape,dtype=int)
    else:

        # filtre des lats_lons concernees pour la zone RDT        
        if abs((max(lons_rdt[ixs_rdt])-min(lons_rdt[ixs_rdt]))-360)>0.125:
            s1=set(np.where((min(lons_rdt[ixs_rdt])<lons_cn) & (lons_cn<max(lons_rdt[ixs_rdt])))[0])
            s2=set(np.where((min(lats_rdt[ixs_rdt])<lats_cn) & (lats_cn<max(lats_rdt[ixs_rdt])))[0])
        else:
            # on coupe le meridien 0
            lons_tmp=lons_rdt[ixs_rdt].copy()
            lons_tmp[lons_tmp>=180]=lons_tmp[lons_tmp>=180]-360
            mn,mx=min(lons_tmp)+360,max(lons_tmp)
            s1=set(np.where(((0<=lons_cn) & (lons_cn<mx)) | ((lons_cn>mn) & (lons_cn<360)))[0])
            s2=set(np.where((min(lats_rdt[ixs_rdt])<lats_cn) & (lats_cn<max(lats_rdt[ixs_rdt])))[0])

        ixs_cn=list(s1.intersection(s2))

        # calcul index sur grille GLOB0125 [0-360[ pour latitudes
        j_cn,i_cn=index_in_glob(lats_cn[ixs_cn],lons_cn[ixs_cn],res=0.125)
        i_cn[i_cn==Nlons_glob]=0
        i_cn[i_cn==-1]=Nlons_glob-1

        ice_crystals_cn_glob=np.ones((Nlats_glob,Nlons_glob),dtype=int)*9999
        ice_crystals_cn_glob[j_cn,i_cn]=cn[ixs_cn]


    ##########################################################"""
    #Combinaison RDT+CPP+CN SUR GRILLE GLOB 
    ############################################################"""
    print("Combinaison RDT+CPP+CN SUR GRILLE GLOB")

    # ICE CRYSTALS CMS : 0  extérieur cercle # 1 pas de nuage ou nuit # 2 ? # 254 nuage non glace # 255 glace
    # CLASSE NUAGEUSE : 1 opaque haut et très haut # 0 sinon
    # si on est dans une zone de nuit (ou de ciel clair) : 2  
    # - on utilise uniquement le rdt filtre par CN (sachant qu'en ciel clair la trace rdt sera nulle) 
    # - si le masque CN est absent, cn initialisé à toujours true : donc on ne garde que la trace rdt
    # si on est en zone de jour, on utilise le masque RDT uniquement filtre par le CPP

    # ttes zones

    tmp=np.ones((Nlats_glob,Nlons_glob),dtype=int)*9999
    # pour les indices où on a du ic dans le produit cms, on prend la valeur risque rdt
    tmp[ ice_crystals_cms_glob==255]=ice_crystals_risk_rdt_glob[ ice_crystals_cms_glob==255]
    tmp[ ice_crystals_cms_glob==254]=0
    # pas de nuage ou nuit
    # intersection entre rdt et classe nuageuse
    tmp[( ice_crystals_cms_glob==1)]=ice_crystals_risk_rdt_glob[ice_crystals_cms_glob==1]*ice_crystals_cn_glob[ice_crystals_cms_glob==1]

    tmp[tmp>=9999]=9999
    # - on applique le masque 9999 en l abscence de donnees
    tmp[ice_crystals_risk_rdt_glob==9999]=9999

    # concatenation pour le grib resultat final
    # on ajoute au grib final toutes les valeurs - on ecrase par les valeur maximale comprise dans [0,1,2,3,4]
    if nz==0:
        #initialisation a la premiere iteration
        ice_crystals_sat=np.ones(tmp.shape)*(-1)
    ice_crystals_sat[(5 > tmp) & (tmp > ice_crystals_sat)] = tmp[(5 > tmp) & (tmp > ice_crystals_sat)]
    
    # plot par zone

    if plot:
        plt.clf()
        lats=np.linspace(90,-90,Nlats_glob,endpoint=True)
        lons=np.linspace(0,360-res_glob,Nlons_glob,endpoint=True)
        lons, lats = np.meshgrid(lons,lats)
        plt.figure(figsize=(20, 16))
        ax=plt.axes(projection=ccrs.PlateCarree())
        ax.coastlines()
        ax.add_feature(cfeature.OCEAN)
        ax.add_feature(cfeature.COASTLINE)
        ax.add_feature(cfeature.BORDERS, linestyle=':')
        ax.set_extent((-180,180,-60,60))
        lons=np.c_[ lons[:,lons.shape[1]//2:]-360, lons[:,0:lons.shape[1]//2] ]
        tmp1=np.c_[ tmp[:,lons.shape[1]//2:], tmp[:,0:lons.shape[1]//2] ]
        cms1=np.c_[ ice_crystals_cms_glob[:,lons.shape[1]//2:], ice_crystals_cms_glob[:,0:lons.shape[1]//2] ]
        rdt1=np.c_[ ice_crystals_risk_rdt_glob[:,lons.shape[1]//2:], ice_crystals_risk_rdt_glob[:,0:lons.shape[1]//2] ]
        cn1=np.c_[ ice_crystals_cn_glob[:,lons.shape[1]//2:], ice_crystals_cn_glob[:,0:lons.shape[1]//2] ]
        cms1[cms1==9999]=-1
        cn1[cn1==9999]=-1
        rdt1[rdt1==9999]=-1

        #plt.contourf(lons, lats,tmp,levels=[0.9,1.9,2.9,3.9,4.9,9999],colors=['#ffff9d','#ffdead' ,'orange','red','grey'])
        cic=plt.contour(lons, lats,ndimage.median_filter(cms1, size=3),levels=[254.5],colors=["red"])
        ccn=plt.contour(lons, lats,ndimage.median_filter(cn1, size=3),levels=[0.9],colors=["blue"])
        crdt=plt.contour(lons, lats,ndimage.median_filter(rdt1, size=3),levels=[0.9],colors=["green"])

        plt.title(zone+"_"+fname_out_png.replace('.png','').replace('_',' '), fontsize=16)
        h1,_ = cic.legend_elements()
        h2,_ = ccn.legend_elements()
        h3,_ = crdt.legend_elements()

        plt.legend([h1[0], h2[0], h3[0]], ['IC CPP', 'High clouds Classif.','RDT trace 120 min'])
        plt.savefig(zone+"_"+fname_out_png, bbox_inches='tight')
        plt.clf()


ice_crystals_sat[ice_crystals_sat==-1]=9999
ice_crystals_sat=ice_crystals_sat.astype(int)

ice_crystals_cms_glob[ice_crystals_sat==9999]=9999
ice_crystals_cn_glob[ice_crystals_sat==9999]=9999


#############################################
# Prod grib + png
#############################################

latglob_final=np.linspace(90,-90,Nlats_glob,endpoint=True)
longlob_final=np.linspace(0,360-res_glob,Nlons_glob,endpoint=True)
longlob_final, latglob_final = np.meshgrid(longlob_final,latglob_final)

# prod grib
write_grib2(ice_crystals_sat,fname_template_grb,fname_out_grb,sat,date,heure,latglob_final[:,0],longlob_final[0,:])


if plot:
    rdt_plot_file="%s_%s.nc"%(dict_rdt[zone]["entete_nc"],lst_dates[0])
    plot_result(ice_crystals_sat,rdt_plot_file,fname_out_png,latglob_final,longlob_final)


