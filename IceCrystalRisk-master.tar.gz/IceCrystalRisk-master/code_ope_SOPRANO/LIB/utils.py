from eccodes import *
import numpy as np

import ssl,os
if (not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None)):
    ssl._create_default_https_context = ssl._create_unverified_context

import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt

import cartopy.crs as ccrs
import cartopy.feature as cfeature


def index_in_glob(lat,lon,res=0.25):

    if res==0.125:
        Ni,Nj=2880,1441
    if res==0.25:
        Ni,Nj=1440,721

    i_f=lon*(Ni-1)/(360-res)
    j_f=(lat-90)*(Nj-1)/(-180)
    return np.around(j_f,0).astype(int),np.around(i_f,0).astype(int)


def write_grib2(tab_in,fname_to_clone,fname_out,sat,date,heure,lats,lons):


    with open(fname_to_clone) as F:
        gid=codes_grib_new_from_file(F)
        # on ouvre un nouveau fichier grib, on boucle sur les niveaux. On ecrit chaque grib dans le fichier
        gidout=codes_clone(gid)
        with open(fname_out,'wb') as fout:
            sat2subCentre={"goes16":1,"goes17":2,"goes18":7,"hima08":3,"hima09":8,"msg1":4,"msg2":6,"msg4":5,"msg3":9}
            codes_set(gidout,'subCentre',sat2subCentre[sat])
            codes_set(gidout,'parameterNumber',194)
            codes_set(gidout,'parameterCategory',1)
            codes_set(gidout,'typeOfFirstFixedSurface',1)
            codes_set(gidout,'dataDate',int(date))
            codes_set(gidout,'dataTime',int(heure))
            codes_set(gidout,'forecastTime',0)
            codes_set(gidout,'stepUnits',0) 
            codes_set(gidout,'latitudeOfFirstGridPoint',int(1000000*lats[0]))
            codes_set(gidout,'latitudeOfLastGridPoint', int(1000000*lats[-1]))
            codes_set(gidout,'longitudeOfFirstGridPoint',int(1000000*lons[0]))
            codes_set(gidout,'longitudeOfLastGridPoint',int(1000000*lons[-1]))

            res_lats=abs(lats[1]-lats[0])
            res_lons=abs(lons[1]-lons[0])
            codes_set(gidout,'jDirectionIncrement',int(1000000*res_lats))
            codes_set(gidout,'iDirectionIncrement',int(1000000*res_lons))

            codes_set(gidout,'Nj',len(lats))
            codes_set(gidout,'Ni',len(lons))


            codes_set_values(gidout,np.ravel(tab_in))

            codes_set(gidout,'bitMapIndicator',0)
            codes_set(gidout,'bitmapPresent',1)
            codes_set(gidout,'missingValue',9999)

            codes_set(gidout,'changeDecimalPrecision',0)

            # packing en grid_second_order
            codes_set(gidout,'packingType', 'grid_second_order')
            codes_set_values(gidout,np.ravel(tab_in))
            codes_set(gidout,'changeDecimalPrecision',0)
            codes_write(gidout,fout)
            codes_release(gidout)
        codes_release(gid)


def plot_result(tab_in,fin_rdt,fname_out,lats,lons):

    levels=[0.9,1.9,2.9,3.9,9999]
    palettecolors=['#b5c8ff','#5371b8','#213e75','grey']

    plt.figure(figsize=(20, 16))
    ax=plt.axes(projection=ccrs.PlateCarree())
    ax.coastlines()
    ax.add_feature(cfeature.OCEAN)
    ax.add_feature(cfeature.COASTLINE)
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.set_extent((-180,180,-60,60))
   
    Nlons_glob=2880
    lons=np.c_[ lons[:,lons.shape[1]//2:]-360, lons[:,0:lons.shape[1]//2] ]
    tab_in=np.c_[ tab_in[:,lons.shape[1]//2:], tab_in[:,0:lons.shape[1]//2] ]


    plt.contourf(lons, lats,tab_in,levels=levels,colors=palettecolors)


    plt.title(fname_out.replace('.png','').replace('_',' '), fontsize=16)
    plt.savefig(fname_out, bbox_inches='tight')
    plt.close()

