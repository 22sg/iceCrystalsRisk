#!/usr/bin/env python
# -*- coding: utf-8 -*-
# utilitaire lancé provisoirement pour controler la présence 
# des fichiers RDT TAR (controle du nombre et de leur chronologie).
# input : directory
# option : 
#       -m / --mode :        
#        hard : s'il manque un seul fichier, on ne lance pas la fabrication du produit ice crystal risk ; 
#        soft : s'il manque un fichier et si le nb de sources récentes est (suffisant : critere 'tolerance'), on poursuit le traitement.
# FIXME : pas encore implémenté ...
#       -t / --tolerance : proportion du nb de sources valides par rapport au nb attendu (default : 0.5 i.e pour msg3, 
#                           si 4 sources RDT sont valides et 4 sources sont manquantes, on poursuit la fabrication du produit).  
import os
from sys import argv, exit
import logging
import argparse
from datetime import datetime, timedelta
from glob import glob1

# exit code : 
#         0 : sortie normale
#         1 : erreur de traitement 
#         2 : anomalie détectée permettant le traitement. Si l'on permet de faire le produit avec un nb mini de sources cohérentes (mode doux actif et suffisamment de srcs rdt).
#         3 : anomalie detectée ne permettant pas le traitement (code utilisée ensuite dans le script principale.) :
#            ex : au moins, 1 source manquante si mode hard actif +  inférieur au nb nécessaire (mode doux actif).
#              \-> sur les creneaux 04 à 05h45, prd ice crystal risk mais sources pas complètes.
EXIT_OK=0
EXIT_KO=1
EXIT_SPE_OK=2
EXIT_SPE_KO=3

def readable_dir(prospective_dir):
	# source : https://stackoverflow.com/questions/11415570/directory-path-types-with-argparse
	import os
	if(not os.path.isdir(prospective_dir)):
		raise argparse.ArgumentTypeError("readable_dir:{0} is not a valid path".format(prospective_dir))
	if(os.access(prospective_dir, os.R_OK)):
		return prospective_dir
	else:
		raise argparse.ArgumentTypeError("readable_dir:{0} is not a readable dir".format(prospective_dir))

#
parser=argparse.ArgumentParser(description="Script de contrôle de cohérence des sources RDT TAR reçues par l'application imgIC (fabrication de l'indice de crystaux de glace).")
parser.add_argument('-dir', metavar='dir', type=readable_dir, help='répertoire à checker',required=True)
parser.add_argument('-m','--mode', metavar='mode', type=str, \
		help='mode de controle : soft(on permet l''absence de N sources valides), hard (on ne tolère aucun manque)',required=False, default='hard',choices=['hard','soft'])
parser.add_argument('-v','--loglvl', metavar='loglvl', type=str, \
		    help='log level (defaut : info, othr : debug)',required=False, default='info',choices=['debug','info'])
#
args = parser.parse_known_args()[0]
try:
   loglvl = args.loglvl
except AttributeError:
   pass
loglvl = loglvl.upper()
lognumlevel = getattr(logging,loglvl)
datfmt = '%d/%m/%Y %H:%M:%S'
logfmt = '%(asctime)s\t%(levelname)-7s\t%(message)s'
logging.basicConfig(level=lognumlevel, format=logfmt, datefmt=datfmt)
#
logging.debug("Rappel de la ligne de commande")
#
for item in argv:
   logging.debug(item)
args = parser.parse_args()
#
rdtDir=args.dir
#
try:
   mode = args.mode
except AttributeError:
   pass
# tolerance :  à ajouter en parametre pour le cas du mode "doux":
tolerance = 0.5 # à minima, 1 source / 2 valide.
# Sur ArchiPEL, le répertoire scruté est celui de l'application (la racine d'install). Il va contenir les fichiers d'obs, détarrés des sources RDT-TAR.
lst_rdt_files=glob1(rdtDir,'*S_NWC*RDT*nc*')
if(len(lst_rdt_files) == 0) : # ne doit pas se produire dans le contexte archipel car gestion des entrées via A_fbr_interface.
   logging.info("absence de fichier RDT dans le répertoire {}".format(rdtDir))
   exit(EXIT_KO)
logging.debug('lst_rdt_files : {}'.format(lst_rdt_files))
# tri dans l'ordre alphabétique de la liste ->  le fichier le + récent se trouve en fin de fichier.
logging.debug('tri de la liste des fichiers')
lst_rdt_files.sort()
# On fige, suivant le satellite traité, le nb de fichier attendu : 
# msg3 - 0 degré : 8 fichiers 
# FIXED : 2023-06-08 : msg3 - 0 degré : 9 fichiers 
# msgoi : 8 
# goes17 et goes18 : 12
# himawari 09 : 6
# -> utilisation de la syntaxe du fichier pour identifier le satellite : 
if (lst_rdt_files[0].__contains__('MSG')): #exemple : S_NWC_RDT-CW_MSG3_globeM-VISIR_20230525T061500Z.nc
   nbMaxSrc = 9
   deltaSlot = 15
elif (lst_rdt_files[0].__contains__('GOES')): 
   nbMaxSrc = 12
   deltaSlot = 10
elif (lst_rdt_files[0].__contains__('HIMA')): 
   nbMaxSrc = 6
   deltaSlot = 20
else : # syntaxe de fichier non conforme : on sort.
   logging.warning("syntaxe du fichier non conforme : pas d'identification possible du satellite à partir de la chaine de caractère {}".format(lst_rdt_files[0]))
   exit(EXIT_KO)
# exemple avec S_NWC_RDT-CW_MSG3_globeM-VISIR_20230525T061500Z.nc
dateRef=lst_rdt_files[-1].split('_')[-1].replace('.nc','')
logging.debug('dateRef : {}'.format(dateRef))
ref=datetime.strptime(dateRef,'%Y%m%dT%H%M%SZ') # FIXME : try/catch à ajouter.
logging.debug('Ref(datetime object) : {}'.format(ref))
# 
nbSrcMq=0
lst_rdt_files_valides=[] # utiliser pour supprimer, à l'inverse, les fichiers présents dans le répertoire qui ne sont pas à utiliser et donc doivent être supprimés.
# boucle sur les sources attendues : 
for k in range(0,nbMaxSrc):
   dateScanned = (ref - timedelta(minutes=k*deltaSlot)).strftime('%Y%m%dT%H%M%SZ')
   fScanned = lst_rdt_files[-1].replace(dateRef,dateScanned) #'S_NWC_RDT-CW_MSG3_globeM-VISIR_{}.nc'.format( date2scan )
   logging.debug('fichier recherché dans la liste : {}'.format(fScanned))
   if(not(fScanned in lst_rdt_files)):
       logging.debug('fichier source {}  absent du repertoire {}'.format(fScanned, rdtDir))
       nbSrcMq+=1
   else:
       logging.debug('Le fichier {} est une source valide'.format(fScanned))
       lst_rdt_files_valides.append(fScanned)
       #pass
# On nettoie les fichiers RDT (obs) non valides du répertoire de scrutation (c-a-d le répertoire racine de l'appli. dans ArchiPEL), les RDT-TAR
#  restent gérés par A_fbr_interface.
for f in lst_rdt_files:
   if(f in lst_rdt_files_valides):
       pass
   else:
       logging.debug("suppression du fichier {}".format( rdtDir + '/' + f))
       try:           
           os.remove(rdtDir + '/' + f)
       except FileNotFoundError:
           logging.warning('Fichier {} impossible à deleter'.format( rdtDir + "/" + f))
           pass # tant pis, on le laisse.
#
logging.debug("Affichage du contenu du répertoire après analyse (et nettoyage éventuel) : {}".format(glob1(rdtDir,'*S_NWC*RDT*nc*')))
# return code qui sera utilisé par prd_ICRisk.
if( mode == 'soft'):
   if(nbSrcMq > int(tolerance * nbMaxSrc)): # ex si on atteint 5 abs (sur 8 prévus) sur msg3.
       logging.info("En mode tolérant actif mais le nb de sources absentes ({}) dépasse le quota prévu ({}).".format(nbSrcMq,int(tolerance * nbMaxSrc)))
       exit(EXIT_SPE_KO) 
   else:
       exit(EXIT_SPE_OK) # éventuellement, ce code retour pourra être mis à 0 pour permettre un traitement par la suite.
if( mode == 'hard'):
   if(nbSrcMq>0):
       logging.info("Mode 'dur' actif : absence d'au moins un fichier source > on sort") # TODO : ajouter les slots absents.
       exit(EXIT_SPE_KO)
   else:
       logging.debug("Mode 'dur' actif : controle des sources OK > poursuite du traitement vers la fabrication du produit IC Risk")
exit(EXIT_OK)
# fin de traitement
