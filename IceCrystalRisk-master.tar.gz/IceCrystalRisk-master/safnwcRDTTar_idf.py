#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Script de reconnaissance des sources RDT-TAR reçues sur 
#  les 5 chaînes geostationnaires du CMS pour fabriquer le produit
#  de risque de fortes concentrations en cristaux de glace (globe*ICrystRiskGT).

import re
from sys import exit
import logging
import argparse
import os
from os.path import basename
import math

# ----- exits codes -------------------------------------------------------------
EXIT_OK = 0  # fin normale
EXIT_KO = 1  # erreur de syntaxe ou d'environnement


# ------------------------------------------------------
# fonctions
# ------------------------------------------------------
#  FIXED  : ajout du paramètre pour prise en compte de la spécificité des msg.

def calc_nnnnn_sat(hh, mn, satid):
   """
   Pour calcul du numero de slot a partir de l'heure
   """
   
   nbslotheure = 2

   if (not (isinstance(hh, int))):
       hh = int(hh)
   if (not (isinstance(mn, int))):
       mn = int(mn)
   # FIXED :  utilisation du code de la classe safnwcCtCmaCtth5_idf.java
   if(satid.__contains__('msg')): 
       hj = hh + float(mn) / 60.
       numslot = int(math.ceil(hj * 2.))
   else: # other satellite.
       if (mn <= 29):
           deltaslot = 0
       else:
           deltaslot = 1
       numslot = hh * nbslotheure + deltaslot

   if (numslot == 0): 
       numslot = nbslotheure * 24
   if (numslot < 10):
       numslot = "0000%i" % numslot
   else:
       numslot = "000%i" % numslot

   return numslot


# ------------------------------------------------------
# logger
# ------------------------------------------------------
lognumlevel = getattr(logging, "INFO")  # par defaut
strpid = str(os.getpid())
logging.basicConfig(format="> %(asctime)s " + strpid + " %(module)s  %(levelname)s :  %(message)s",
                    level=lognumlevel, datefmt="%Y/%m/%d %H:%M:%S")

# ------------------------------------------------------
# recuperation des arguments
# ------------------------------------------------------
parser = argparse.ArgumentParser(description="script d'identification des fichiers produits par les chaines des SAFNWC et reçus sur les chaines des 5 satellites geostationnaires.", conflict_handler='resolve')
parser.add_argument('-s', action='store_true', help="SATIMG uniquement")
parser.add_argument('-d', action='store_true', help="YYYYMMDD uniquement")
parser.add_argument('-h', action='store_true', help="HHMN uniquement")
parser.add_argument('-n', action='store_true', help="NNNNN uniquement")
parser.add_argument('-i', action='store_true', help="Affiche l'ensemble des champs c-a-d \"SATIMG YYYYMMDD HHMMSS NNNNN\"")
parser.add_argument('file_src', metavar='file_src', type=argparse.FileType('r'), help="chemin complet vers le fichier source.")

args = parser.parse_known_args()[0]
logging.debug("args : ")
logging.debug(args)

file_path = args.file_src.name
filename = basename(file_path)

# ------------------------------------------------------
# traitement
# ------------------------------------------------------
# reconnaissance des sources par rapport a leur syntaxe uniquement.
#   ex: 
#      S_NWC_RDT-TAR_MSG3_globeM-VISIR_20230514T120000Z.tar.gz.moonseed3220x
#      S_NWC_RDT-TAR_GOES16_globeE-NR_20230514T180000Z.tar.gz.moonseed4220x
#      S_NWC_RDT-TAR_HIMA09_globeJ-NR_20230516T060000Z.tar.gz.moonseed3220x.v2021
#      EDXI51IODC160900.SAFNWC_MSG2_RDT-TAR__202305160900_globeI.tar.gz.LT ?
msgError = "source non valide"
#  S_NWC_RDT-TAR_MSG3_globeM-VISIR_20230514T120000Z.tar.gz.moonseed3220x
m = re.search('S_NWC_RDT-TAR_(?P<sat>\w+)_(?P<nonUtile>\w+)-(?P<nonUtile2>\w+)_(?P<yyyymmdd>\d{8,8})T(?P<hhmn>\d{4,6})Z',filename)
if (m is None):
   # nommage archipel : RDTTar_msg03_20230516_234500_00048_interne_0
   m = re.search('(?P<nonUsed>\w+)_(?P<sat>\w+)_(?P<yyyymmdd>\d{8,8})_(?P<hhmn>\d{4,6})_(?P<nnnnn>\d{5,5})_', filename)
   if (m is None):
       print(msgError)
       exit(1)
   sat_name = m.group('sat')
   yyyymmdd = m.group('yyyymmdd')
   hhmn = m.group('hhmn')
   nnnnn = m.group('nnnnn')

else:
   # nommage de la rcp.
   if m.group('sat') == 'MSG2': 
       sat_name = 'msg02'
   elif m.group('sat') == 'MSG3': 
       sat_name = 'msg03'
   elif m.group('sat') == 'GOES16':
       sat_name = 'goes16'
   elif m.group('sat') == 'GOES18':
       sat_name = 'goes18'
   elif m.group('sat') == 'HIMA09':
       sat_name = 'hima09'
   else:
       sat_name = 'UNK'
   yyyymmdd = m.group('yyyymmdd')
   hhmn = m.group('hhmn')
   nnnnn = calc_nnnnn_sat(hhmn[:2], hhmn[2:4],sat_name)

# impression de l information demandee
if ((args.i) or (not (args.i) and not (args.s) and not (args.d) and not (args.h) and not (args.n))):
   print(("%s %s %s %s" % (sat_name, yyyymmdd, hhmn, nnnnn)).strip())
else:
   chaine = ""
   if (args.s): chaine = "%s" % sat_name
   if (args.d): chaine = "%s %s" % (chaine, yyyymmdd)
   if (args.h): chaine = "%s %s" % (chaine, hhmn)
   if (args.n): chaine = "%s %s" % (chaine, nnnnn)
   print(chaine.strip())

exit(EXIT_OK)
# fin de traitement