#!/usr/bin/env python
# -*- coding: utf-8 -*-
#------------------------------------------------------------------------------
# makeIWCncfile.py version 1.1 du 4/5/2021. (C) METEO-FRANCE
#------------------------------------------------------------------------------
#++
# NOM
#	makeIWCncfile.py
#
# SOMMAIRE
#	Génération du produit globeMhiwcMaskNC de la chaîne msg.
#
# DOMAINE D'INTÉGRATION.
#	ArchiPEL_MSG
#
# SYNTAXE	
#
# DESCRIPTION
#
# OPTIONS
#
# ENVIRONNEMENT
#	ArchiPEL
#
# FICHIERS
#
# NOTES
#	voir aussi makeIWCgeotiff.py
# AUTEUR(S)
#	stephane.guevel@meteo.fr
# DATE DE CRÉATION
#	24/07/2019.
# DERNIERE MODIFICATION
#	24/07/2019
#	4/5/2021 :	indentations régulières pour python 3. Périer.
# VERSION.RELEASE
#	1.1
#--


from netCDF4 import Dataset
import os
from os.path import basename
from sys import argv, exit
import numpy as np
import logging
import argparse
from datetime import datetime
from  glob import glob1
from scipy import ndimage
from osgeo import osr,gdal


def readable_dir(prospective_dir):
	# source : https://stackoverflow.com/questions/11415570/directory-path-types-with-argparse
	import os
	if(not os.path.isdir(prospective_dir)):
		raise argparse.ArgumentTypeError("readable_dir:{0} is not a valid path".format(prospective_dir))
	if(os.access(prospective_dir, os.R_OK)):
		return prospective_dir
	else:
		raise argparse.ArgumentTypeError("readable_dir:{0} is not a readable dir".format(prospective_dir))


#
parser=argparse.ArgumentParser(description="Script de génération d'un produit de probabilité d'occurence de forte concentration en cristaux de glace.")
parser.add_argument('-cmic', metavar='cmic', type=argparse.FileType('rb'), help='safnwc CMIC product',required=True)
parser.add_argument('-ctth', metavar='ctth', type=argparse.FileType('rb'), help='safnwc CTTH product',required=True)
parser.add_argument('-ct', metavar='ct', type=argparse.FileType('rb'), help='safnwc Cloud Type product',required=True)
parser.add_argument('-rdt', metavar='rdt', type=readable_dir, help='safnwc RDT products directory',required=True)
parser.add_argument('-out', metavar='out', type=argparse.FileType('wb'), help='ouput product file',required=True)
parser.add_argument('-anvil', metavar='anvil', type=int,help='nb pixels pris en compte autour des enclumes')
#
args = parser.parse_known_args()[0]
lognumlevel = getattr(logging, "DEBUG")
datfmt = '%d/%m/%Y %H:%M:%S'
logfmt = '%(asctime)s\t%(levelname)-7s\t%(message)s'
logging.basicConfig(level=lognumlevel, format=logfmt, datefmt=datfmt)
#
logging.debug("Rappel de la ligne de commande")
#
for item in argv:
	logging.debug(item)
args = parser.parse_args()
#
cmicFile=args.cmic.name 
ctthFile=args.ctth.name
ctFile=args.ct.name
rdtDir=args.rdt
#try:
outfile=args.out.name
#except:
#	#S_NWC_CMIC_MSG4_globeM-VISIR_20180328T154500Z.nc
#	outfile=basename(cmicFile).replace('CMIC','maskICW-PROTO')	
#	logging.info("no outfile passed > dump file may be %s" % outfile)


# Reprise de l'algo permettant de calculer le masque de présence du phénomène : 
#  e
#FIXME : controle des entrees
ctthNcFile=Dataset(ctthFile,mode='r')
cmicNcFile=Dataset(cmicFile,mode='r')
ctNcFile=Dataset(ctFile,mode='r')
# recuperation des attributs globaux de geo-ref
cmicGlobAttrs=cmicNcFile.ncattrs()
selectAttrs=['gdal_projection','gdal_geotransform_table','gdal_xgeo_up_left','gdal_ygeo_up_left','gdal_xgeo_low_right','gdal_ygeo_low_right','geospatial_lat_max','geospatial_lat_min','geospatial_lon_max','geospatial_lon_min','time_coverage_start','time_coverage_end']
for k in selectAttrs :
	logging.debug(k)
	logging.debug(cmicNcFile.getncattr(k))

# TODO : à reprendre pour la gestion des exceptions.
if(not(args.anvil is None)):
	anvil=args.anvil #integer mandatory.
else:
    try:
        logging.debug("anvil not filled : we'rg going to calculate this parameter")
        anvil=cmicNcFile.gdal_geotransform_table[1] 
		# GT : array([-5.4348955e+06,  2.0040175e+03,  0.0000000e+00,  5.4348955e+06,
		#  0.0000000e+00, -2.0040175e+03], dtype=float32).
        anvil = int(np.ceil(100*10**3 / anvil)) # arrondi à l'entier supérieur : pour goes16:50
    except AttributeError:
	    # si attribut gdal_geotransform_table absent, on sort.
        logging.error("general attribute 'dal_geotransform_table' absent : exit error")

logging.debug('anvil parameter (nb pixels corresponding to 100 km) : {}'.format(anvil))
cloudPhase=cmicNcFile.variables['cmic_phase']
cloudOpticalThickness=cmicNcFile.variables['cmic_cot']
liquidWaterPath=cmicNcFile.variables['cmic_lwp']
iceWaterPath=cmicNcFile.variables['cmic_iwp']
cloudTopTemperature=ctthNcFile.variables['ctth_tempe']
#FIXME CLB : rempplacement de la tempe par la pression
#cloudTopAlti=ctthNcFile.variables['ctth_alti']
cloudTopPres=ctthNcFile.variables['ctth_pres']
ctthConditions=ctthNcFile.variables['ctth_conditions']
mask=np.array(cloudPhase.shape,dtype=np.ubyte)
#
CWP=liquidWaterPath[:,:]+iceWaterPath[:,:]
COT=cloudOpticalThickness[:,:]
COT=np.where(cloudOpticalThickness[:,:].mask,0,COT)
CP=cloudPhase[:,:]
CTT=cloudTopTemperature[:,:]
CTTHCONDITIONS=ctthConditions[:,:]
logging.info("pourcentage de pts dans l espace (ctth_conditions = 2) : %f" % (100. * np.sum(CTTHCONDITIONS==1) / float(CTTHCONDITIONS.size))) 
try:
	# on recupere la valeur de remplissage du dataset ctth_alti (65535) et l'offset(-2000)
	#FIXME ALTI=np.where(cloudTopAlti[:,:].mask, cloudTopAlti._FillValue, ( cloudTopAlti.scale_factor*cloudTopAlti[:,:]+cloudTopAlti.add_offset).astype(dtype='uint16'))
	# valeurs compressees de 0 a 11000 -> decompressees de 0 a 110 000 -> on passe en hPa avec l'application d un coef de 0.01 -> valeurs comprises 
	# dans le netcdf de 0 a 1100 hPa.
	PRES=np.where(cloudTopPres[:,:].mask, cloudTopPres._FillValue, (np.round(0.01*cloudTopPres.scale_factor*cloudTopPres[:,:]+cloudTopPres.add_offset)).astype(dtype='uint16'))
	logging.debug("PRES.dtype : %s" % PRES.dtype)
except:
	logging.warning("exception lors de linitialisation du tableau numpy PRES")
	pass
#FIXME logging.debug(" cloudTopAlti min : %s / max : %s" % (ALTI.min(),ALTI.max()))
logging.debug(" cloudTopPres min : %s / max : %s" % (PRES.min(),PRES.max()))
logging.debug(" CWP min : %f / max : %f" % (CWP.min(),CWP.max()))
logging.debug(" CTTH min : %f / max : %f" % (CTT.min(),CTT.max()))
#FIXME 2019-09-11 SG : ajustement du parametre CTTH pour enlever les zones detectees pres des cirrus. 
# C(loud)P(hase) = 2 : présence de glace.
# CWP = liquidWaterPath + iceWaterPath 
# COT = épaisseur optique des nuages.
# CTT = temperature du sommet des nuages.
SEUIL_CTTH=270.
mask=np.where( (CP==2) & (CWP>0.1) & (CTT < SEUIL_CTTH) & (COT > 20) , 255, 254)
#FIXME 2019-09-13 SG intervertion des criteres "sans nuages" puis "COT nul" -> il semble que le critere "COT a zero"
#	contienne le critere "CP a 2". 
mask=np.where(CP==3,2,mask)
mask=np.where((COT==0),1, mask) # no data du COT mask -> 255
#FIXME dans lespace, on met les comptes a 0.
mask=np.where( (CTTHCONDITIONS==1),0, mask) # no data du COT mask -> 255
#FIXME 2019-09-10 SG-CLB cmic_phase = cloud free(=3) -> cn du mask = 2 
#mask=np.where(CP==3,2,mask)
logging.info("pourcentage de pts correspondant au critere IWC : %f" % (100. * np.sum(mask==255) / float(mask.size)))
logging.info("pourcentage de pts ne correspondant pas au critere IWC : %f" % (100. * np.sum(mask==254) / float(mask.size)))
logging.info("pourcentage de pts sans nuage (cloud free) : %f" % (100. * np.sum(mask==2) / float(mask.size)))
logging.info("pourcentage de pts a no_data : %f" % (100. * np.sum(mask==1) / float(mask.size)))
logging.info("pourcentage de pts dans l'espace : %f" % (100. * np.sum(mask==0) / float(mask.size)))
# attrib global : pourcentage du disque rempli.
Rate_of_invalid_data=100.*np.sum(mask==1)/(np.sum(mask==255)+np.sum(mask==254)+np.sum(mask==2)+np.sum(mask==1))
Rate_of_valid_data=100.-Rate_of_invalid_data
100.*np.sum(mask==1)/(np.sum(mask==255)+np.sum(mask==254)+np.sum(mask==2)+np.sum(mask==1))
logging.info("Rate_of_invalid_data=%i" % np.round(Rate_of_invalid_data))
logging.info("Rate_of_valid_data=%i" % np.round(Rate_of_valid_data))
#
noLat=False
noLon=False
try:
	lat=cmicNcFile.variables['lat']
except KeyError:
	logging.info("Le dataset %s est abs du netcdf %s" % ('lat',cmicFile))
	noLat=True
try:
	lon=cmicNcFile.variables['lon']
except KeyError:
	logging.info("Le dataset %s est abs du netcdf %s" % ('lon',cmicFile))
	noLon=True


# Filtrage suivant les classes de nuages.
#  ' 1:  Cloud-free land',
#  ' 2:  Cloud-free sea',
#  ' 3:  Snow over land',
#  '  4:  Sea ice',
#  ' 5:  Very low clouds',
#  ' 6:  Low clouds',
#  ' 7:  Mid-level clouds',
#  '  8:  High opaque clouds',
#  ' 9:  Very high opaque clouds',
#  '  10:  Fractional clouds',
#  ' 11:  High semitransparent thin clouds',
#  '  12:  High semitransparent moderately thick clouds',
#  '  13:  High semitransparent thick clouds',
#  '  14:  High semitransparent above low or medium clouds',
#  '  15:  High semitransparent above snow/ice'
#  TODO : vérifier cette sélection, le commentaire mentionnant les classes 12 à 14.
logging.info("Filtrage suivant les classes de nuages")
logging.info("le masque 'nuages hauts' comprend les classes de 11 à 14 et 9")
maskCn=( ((ctNcFile.variables['ct'][:,:].data >=11)&(ctNcFile.variables['ct'][:,:].data <=14)) | (ctNcFile.variables['ct'][:,:].data==9) ) # tableau 2D de booléens.
maskCn = maskCn.astype(int) # conversion vers  entier : False -> 0 / True -> 1.

logging.info("traitement des données de RDT : ")
# TODO : ajouter une commande d'extraction (éventuellemeent via module subprocess) du fichier d'obs uniquement (à priori).
#   A défaut, cette extraction peut être gérée via l'application interface d'ArchiPEL.

# infos du dataset MapCellCatType : 
# 0:Non_convective
# 1:Convective_triggering
# 2:Convective_triggering_from_split
# 3:Convective_growing
# 4:Convective_mature
# 5:OvershootingTop_mature
# 6:Convective_decaying
# 7:Electric_triggering
# 8:Electric_triggering_from_split
# 9:Electric_growing
# 10:Electric_mature
# 11:Electric_decaying
# 12:HighRainRate_triggering
# 13:HighRainRate_triggering_from_split
# 14:HighRainRate_growing
# 15:HighRainRate_mature
# 16:HighRainRate_decaying
# 17:HighSeverity_triggering
# 18:HighSeverity_triggering_from_split
# 19:HighSeverity_growing
# 20:HighSeverity_mature
# 21:HighSeverity_decaying

# HYP : la selection des sources RDT à utiliser a été faite avant dans ce script ou au niveau du script applicatif.
# MSG3   : S_NWC_RDT-CW_MSG3_globeM-VISIR_20230509T100000Z.nc
# GOES16 : S_NWC_RDT-CW_GOES16_globeE-NR_20230514T161000Z.nc
lst_rdt_files=glob1(rdtDir,'S_NWC_RDT-CW_*Z.nc') #FIXME à adapter suivant syntaxe.
logging.debug('lst_rdt_files : {}'.format(lst_rdt_files.__str__()))
if(lst_rdt_files is None):
	logging.error("Absence de données de RDT sous {}".format(rdtDir))
	exit(1)
# une liste...
tabRdt=[]
nbRdt=0 #doit valoir 8 pour msg3 (1 obs toutes les 15' / 8 obs sur 2 h...). 
# lecture des données de RDT.
lst_rdt_files.sort()
for rdtf in lst_rdt_files:
	logging.debug(rdtDir +'/' + rdtf)
	tabRdt.append(Dataset(rdtDir +'/' + rdtf,mode='r').variables['MapCellCatType'][:,:].data) # tableau 2D.
	nbRdt+=1
logging.debug('nbRdt:{}'.format(nbRdt))
#
maskRdt = np.zeros(tabRdt[0].shape,dtype=bool) #trace de la cellule  
maskOvt = np.zeros(tabRdt[0].shape,dtype=bool) #la trace de la cellule avec la categorie overshoot=finalovs
maskDecay = np.zeros(tabRdt[0].shape,dtype=bool) #la trace de la cellule avec la categorie decroissance=finaldecay
maskPrecip = np.zeros(tabRdt[0].shape,dtype=bool) #la trace de la cellule avec la categorie fort taux de precipitation (non utilise)
#
for k in range(nbRdt):
	maskRdt=maskRdt+((tabRdt[k]>0) & (tabRdt[k]<22)) # ~ (rdt>1)
	maskOvt=maskOvt+(tabRdt[k]==5)
	maskDecay=maskDecay+(tabRdt[k]==6) + (tabRdt[k]==11)+ (tabRdt[k]==16)+(tabRdt[k]==21)
	maskPrecip=maskPrecip+(tabRdt[k]==15) + (tabRdt[k]==16)
# conversion des masks de type booléen en int pour calcul des risques.
maskRdt = maskRdt.astype('ubyte')
maskOvt = maskOvt.astype('ubyte')
maskDecay = maskDecay.astype('ubyte')
maskPrecip = maskPrecip.astype('ubyte')
# trace de la cellule en fonction des categorie finalcellule + on regroupe les classes 3 et 4 --> 3
icRisk = np.zeros(tabRdt[0].shape,dtype='ubyte')
icRisk = maskRdt + 2*maskOvt + maskDecay
icRisk[icRisk==4]=3
# on étend le domaine ciblé par la trace rdt pour inclure les enclumes (~100 km)
# FIXME : paramètre à vérifier avec DSM/AERO ou à ajuster en pratique
#   car en pratique : 9 pixels à résolution 0.125 degrés = 1.125 degrés <-> 1.125 * 60 * 1.852 = 125.01 km.
#_size=34 #MSG3
#  100 km -> 50 pix  sur GOES16
icRisk=ndimage.maximum_filter(icRisk,size=anvil)

# ICE CRYSTALS CMS : 0  extérieur cercle 
# 					 1 
# 					 2  no data / nuit 
#  				   254 nuage non glace 
# 				   255 glace
# CLASSE NUAGEUSE : 1 opaque haut et très haut 
#                   0 sinon
#                   2 si on est dans une zone de nuit (ou de ciel clair).  
# - on utilise uniquement le rdt filtre par CN (sachant qu'en ciel clair la trace rdt sera nulle) 
# - si le masque CN est absent, cn initialisé à toujours true : donc on ne garde que la trace rdt
# si on est en zone de jour, on utilise le masque RDT uniquement filtre par le CPP
tmp=np.zeros(icRisk.shape,dtype=int) # initialisation avec les no_data à 0.
# pour les indices où on a du ic dans le produit cms, on prend la valeur risque rdt
tmp[mask==255]=icRisk[mask==255]
tmp[mask==254]=0
#
# pas de nuage ou nuit
# intersection entre rdt et classe nuageuse
#tmp[mask==1]=icRisk[mask==1]*maskCn[mask==1]
#tmp[mask==2]=icRisk[mask==2]*maskCn[mask==2]
#tmp[(mask==1)&(maskCn==1)]=icRisk[(mask==1)&(maskCn==1)]
#tmp[(mask==1)|(maskCn==0)]=icRisk[(mask==1)|(maskCn==0)] *maskCn[(mask==1)|(maskCn==0)]
tmp[(mask==2)|(mask==1)]=icRisk[(mask==2)|(mask==1)]*maskCn[(mask==2)|(mask==1)]
# - on applique le masque no_data en l abscence de donnees
tmp[icRisk==0]=0
#
logging.info("Ecriture du Geotiff")
# 
logging.info("recuperation de la projection")
proj=cmicNcFile.getncattr('gdal_projection')
logging.debug('proj : {}'.format(proj))
#
logging.info("recuperation des parametres gdal_xgeo_up_left gdal_ygeo_up_left gdal_xgeo_low_right gdal_ygeo_low_right")
ulx=cmicNcFile.getncattr('gdal_xgeo_up_left')
uly=cmicNcFile.getncattr('gdal_ygeo_up_left') 
lrx=cmicNcFile.getncattr('gdal_xgeo_low_right')
lry=cmicNcFile.getncattr('gdal_ygeo_low_right')
logging.debug('ulx:{} uly:{} lrx:{} lry:{}'.format(ulx,uly,lrx,lry))
# taille des tableaux / dimensions : 
nx=cmicNcFile.dimensions['nx'].size
ny=cmicNcFile.dimensions['ny'].size
logging.info("calculs des parametres 'GeoTransform'")
incremx=(lrx-ulx)/nx
incremy=(uly-lry)/ny
gt=[ulx,incremx, 0, uly, 0, -incremy]
logging.debug("gt:{}".format(gt.__str__()))
#
logging.info("construction du wkt_srs")
srs=osr.SpatialReference()
#srs.ImportFromProj4(Proj(proj).definition_string())
srs.ImportFromProj4('{}'.format(proj))
wkt_srs=srs.ExportToWkt()
logging.debug(wkt_srs)
#"ecriture du fichier geotiff"
logging.info("ecriture du fichier geotiff")
driver=gdal.GetDriverByName('GTiff')
dst_ds=driver.Create(outfile,ny,ny,1,gdal.GDT_Byte,['COMPRESS=LZW'])
dst_ds.SetProjection(wkt_srs)
dst_ds.SetGeoTransform(gt)
bd=dst_ds.GetRasterBand(1)
bd.WriteArray(tmp)
dst_ds=None
if(not(os.path.isfile(outfile))):
	logging.error("pb ecriture du geotiff %s" % outfile)
	logging.info("fin du traitement")
	exit(1)
logging.info("fin ecriture du fichier en geotiff sous %s" % outfile)
#
exit(0)
#fin traitement