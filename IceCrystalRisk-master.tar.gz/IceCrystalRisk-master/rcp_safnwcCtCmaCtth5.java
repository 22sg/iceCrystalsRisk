/*#! 
!
! @(#)rcp_safnwcCtCmaCtth5.java version 1.2 du 7/11/2017.
!
!++
! NOM
!	rcp_safnwcCtCmaCtth5.java
! SOMMAIRE
!	Interface de reconnaissance d'une source en hdf5 (v2013) ou en netcdf (v2016) 
!       . CTh5 (cloud type), 
!       . CMah5 (cloud mask), 
!       . CTTh5 (temperature ou pression au sommet des nuages), 
!       . RDT (Rapid Developping Thunderstorm)
!       ainsi que les tifs à destination de l'appli imgW3.
!	Pour la réception safnwc de la chaîne msg.
!
! DOMAINE D'INTEGRATION.
!	cms
! SYNTAXE
!	java rcp_safnwcCtCmaCtth5 file
! COMPILATION.
!	javac rcp_safnwcCtCmaCtth5.java
!
! DESCRIPTION
!	rcp_safnwcCtCmaCtth5 fournit l'identificateur (srcid) d'une source : CTh5, CMah5, CTTh5.
! COMPILATION.
!	javac rcp_safnwcCtCmaCtth5.java -encoding iso-8859-1
!
! VERSION
!	3/12/2014 :	CTTh5 => CTTHh5. NON.
!	30/1/2017 :	CMa => CMA à cause de la version du saf V2016.
!	7/11/2017 :	rajout de globeMnuc et euratlMnuc pour les tiffmfs en provenance de la chaîne du SAF 
!			et à destination de l'application imgW3.
!	24/7/2019 :	reconnaissance du produit de la chaine safnwc16 CMIC
!	31/05/2023 :	reconnaissance du produit RDT de la chaine safnwc21.
! 
*/
import java.io.*;
import java.util.*;
import java.lang.*;

public class rcp_safnwcCtCmaCtth5
	{

	public static void main(String[] args)
		{

		// Lecture des arguments
		File	filerecu= new File(args[0]);
		String	filerecuname = filerecu.getName();
			// SAFNWC_MSG3_CMa__201402051400_globeM______.h5.penhir
			// SAFNWC_MSG3_CTTH_201402051400_globeM______.h5.penhir
			// SAFNWC_MSG3_CT___201402051400_globeM______.h5.penhir

		// Analyse du nom du fichier (identification syntaxique)

		// Inscription du nom de la source si elle est reconnue :
		if ((filerecuname.contains("CMa")) || (filerecuname.contains("CMA")))
			// Rajout de CMA pour la V2016. Janvier 2017.
			System.out.println("CMah5");

		else if (filerecuname.contains("CTTH"))
			System.out.println("CTTh5");
			// System.out.println("CTTHh5");
			// CTTh5 => CTTHh5 le 3/12/2014.

		else if (filerecuname.contains("CT_"))
			System.out.println("CTh5");

		else if ((filerecuname.contains("S_NWC_nuc")) && (filerecuname.contains("globe")))
			// S_NWC_nuc_MSG3_globeM-VISIR_20171107T133000Z.tif
			System.out.println("globeMnuc");

		else if ((filerecuname.contains("S_NWC_nuc")) && (filerecuname.contains("euratl")))
			// S_NWC_nuc_MSG3_euratlM-VISIR_20171107T133000Z.tif
			System.out.println("euratlMnuc");
		else if (filerecuname.contains("CMIC"))
			System.out.println("CMICh5");
		else if (filerecuname.contains("S_NWC_RDT-TAR_"))
			System.out.println("RDTTar");
		else
			{
			System.out.println("FichierNonAttendu");
			System.exit(1);
			}

		} // fin du main

	} // fin de la classe.

