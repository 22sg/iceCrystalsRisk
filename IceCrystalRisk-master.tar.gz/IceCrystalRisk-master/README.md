# IceCrystalRisk
Projet développement commun avec DSM AERO RIO (2023-05) sur un nouveau 
produit 'risque de forte concentration en cristaux de glace'.
L'objet de ce projet : 
- porter sur le système de production ArchiPEL la fabrication de produit 
  et pour cela porter l'algo utilisé actuellement sur la tâche SOPRANO ; 
- comparer les produits issus des 2 systèmes ; 
- une fois validée, la production issu du CMS remplacera celle de SOPRANO,
  celle-ci pourra donc être désactivée.

# 2023-06-07 : 
- prise en compte dans le masque nuages élevés de la classe 'Very high opaque clouds' ; 
- ajout d'un fichier RDT suppplémentaire (slot - 2h).
