#!/usr/bin/env python
# -*- coding: utf-8 -*-
#------------------------------------------------------------------------------
# le=Dataset(maskIWCFile,'r')ff.py version 1.0 24/07/2019 (C) METEO-FRANCE
#------------------------------------------------------------------------------
#++
# NOM
#  makeIWCgeotiff.py
# SOMMAIRE
#  generation produit globeMhiwcGT
# PACKAGE
# ArchiPEL_MSG
#
# SYNTAXE
#   voir plus bas.
# DESCRIPTION
#
# OPTIONS
#
# ENVIRONNEMENT
#   ArchiPEL
#
# FICHIERS
#
# NOTES
#	voir aussi  makeIWCncfile.py
#
# AUTEUR(S)
#	stephane.guevel@meteo.fr
# DATE CREATION
#  24/07/19
# DERNIERE MODIFICATION
# 24/07/2019
# 31/03/2019 georeferencement differencie pour chaque satellite
# VERSION.RELEASE
# 1.0
#--

from netCDF4 import Dataset
import os
from os.path import basename
from sys import argv, exit
import numpy as np
import logging
import argparse
from osgeo import gdal,osr
from pyproj import Proj
#
parser=argparse.ArgumentParser(description='generation d un produit associe a l indice Ice Water Content au format geotiff')
parser.add_argument('-ncfile', metavar='ncfile', type=argparse.FileType('rb'), help='produit masque IWC au formar netcdf',required="True")
parser.add_argument('-out', metavar='out', type=argparse.FileType('wb'), help='mask product geotiff')
#
args = parser.parse_known_args()[0]
lognumlevel = getattr(logging, "DEBUG")
datfmt = '%d/%m/%Y %H:%M:%S'
logfmt = '%(asctime)s\t%(levelname)-7s\t%(message)s'
logging.basicConfig(level=lognumlevel, format=logfmt, datefmt=datfmt)
#
logging.debug("Rappel de la ligne de commande")
#
for item in argv:
	logging.debug(item)
args = parser.parse_args()
#
maskIWCFile=args.ncfile.name
try:
	outfile=args.out.name
except:
	#S_NWC_CMIC_MSG4_globeM-VISIR_20180328T154500Z.nc
	outfile=basename(maskIWCFile).replace('.nc','.mask.gtiff')	
	logging.info("no outfile specified > out file will be %s" % outfile)
#TODO ajouter le controle des entrees
ncfile=Dataset(maskIWCFile,'r')
logging.info("recuperation de la projection et des bornes du domaine a partir des metadonnees du ncfile en entree")
proj=ncfile.getncattr('gdal_projection')
#
logging.info("recuperation des parametres gdal_xgeo_up_left gdal_ygeo_up_left gdal_xgeo_low_right gdal_ygeo_low_right")
ulx=ncfile.getncattr('gdal_xgeo_up_left')
uly=ncfile.getncattr('gdal_ygeo_up_left') 
lrx=ncfile.getncattr('gdal_xgeo_low_right')
lry=ncfile.getncattr('gdal_ygeo_low_right')
logging.info("gdal_xgeo_up_left :")
logging.info(ulx)
logging.info("gdal_ygeo_up_left :")
logging.info(uly)
logging.info("gdal_xgeo_low_right :")
logging.info(lrx)
logging.info("gdal_ygeo_low_right :")
logging.info(lry)
#FIXED 2019-07-25 FB , pour les 6 lignes suivantes.
#ulx=-5570254.
#uly=5570254.
#lrx=5567253.
#lry=-5567253.
#incremy=(5570253.813501345+5567253.407461215)/3712.
#incremx=(5570253.813501345+5567253.407461215)/3712.
logging.info("recuperation du tableau 'mask'")
MASK=ncfile.variables['mask'][:,:]
ncfile.close()
logging.info("fermeture du fichier en entree")
#
logging.info("recuperation des parametres de resolution")
try :
	resolx=float(MASK.shape[0])
	resoly=float(MASK.shape[1])
except :
	logging.info("CONVERSION resolx resoly en float IMPOSSIBLE")
	resolx=MASK.shape[0]
	resoly=MASK.shape[1]
logging.info("MASK.shape[0] : resolx")
logging.info(resolx)
logging.info("MASK.shape[1] : resoly")
logging.info(resoly)
# calculs
logging.info("calculs incremx incremy")
incremx=(lrx-ulx)/resolx
incremy=(uly-lry)/resoly
#
logging.info("calcul de la liste 'GeoTransform'")
#FIXED 2019-07-25 FB :
gt=[ulx,incremx, 0, uly, 0, -incremy]
logging.debug(gt)
#proj=Proj4(proj)
logging.info("construction du wkt_srs")
srs=osr.SpatialReference()
#srs.ImportFromProj4(Proj(proj).definition_string())
srs.ImportFromProj4('{}'.format(proj))
wkt_srs=srs.ExportToWkt()
logging.debug(wkt_srs)
#
logging.info("creation du fichier")
driver=gdal.GetDriverByName('GTiff')
dst_ds=driver.Create(outfile,MASK.shape[1],MASK.shape[0],1,gdal.GDT_Byte,['COMPRESS=LZW'])
dst_ds.SetProjection(wkt_srs)
dst_ds.SetGeoTransform(gt)
bd=dst_ds.GetRasterBand(1)
bd.WriteArray(MASK)
dst_ds=None
if(not(os.path.isfile(outfile))):
	logging.error("pb ecriture du geotiff %s" % outfile)
	logging.info("fin du traitement")
	exit(1)
logging.info("fin ecriture du fichier en geotiff sous %s" % outfile)
exit(0)
#fin
