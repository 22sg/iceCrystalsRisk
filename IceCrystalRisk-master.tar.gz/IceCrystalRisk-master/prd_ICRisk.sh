#! /bin/sh
#------------------------------------------------------------------------------
# @(#)prd_IWCncfile.sh version 1.0 24/07/2019 (C) METEO-FRANCE
#------------------------------------------------------------------------------
#++
# NOM
#   prd_IWCncfile
#
# SOMMAIRE
##  generation produit globeMhiwcNC
#
# PACKAGE
# ArchiPEL_MSG
#
# SYNTAXE
#   prd_ICRisk -S srcid -P prdid -s satimg -d yyyymmdd -h hhmn -n sssss file_src
#
# DESCRIPTION
#   - Consomme les sources RDTTar, CTh5, CTTh5 et CMICh5 venant des chaines du safnwc.
#   - Elabore le produit globe*ICRiskGT, au format GTiff.
#
# OPTIONS
#   -S srcid
#   identificateur de la source : CTTh5, CMICh5
#   Cette cle est obligatoire.
#
#   -P prdid
#   identificateur du produit : globeMhiwcMaskNC
#   Cette cle est obligatoire.
#
#   -s satimg
#   identificateur du satellite image (ex: msg04)
#   Cette cle est obligatoire.
#
#   -d yyyymmdd
#   date de reference de la (des) source(s)
#   Cette cle est obligatoire.
#
#   -h hhmn[ss]
#   heure de reference de la (des) source(s)
#   ss vaut 00 si non precise
#   Cette cle est obligatoire.
#
#   -n sssss
#   numero de slot de la (des) source(s)
#   Cette cle est optionnelle.
#
# ENVIRONNEMENT
#   ArchiPEL v3.
#
# FICHIERS
#
# NOTES
#
# AUTEUR(S)
#
# DATE CREATION
#  
# DERNIERE MODIFICATION
#  
# VERSION.RELEASE
# 1.0
#--
#==============================================================================
# fonctions specifiques
#==============================================================================

#------------------------------------------------------------------------------
prd_exit()
#------------------------------------------------------------------------------
{
	log_info $2
	exit $1
}

#------------------------------------------------------------------------------
test_return_code()
#------------------------------------------------------------------------------
{
	if [ $1 -ne 0 ] ; then
		prd_exit $1 $2
	fi
}


#==============================================================================
# main 
#==============================================================================

#------------------------------------------------------------------------------
# chargement standard
#
. liblog.sh
#------------------------------------------------------------------------------


log_info $*

# recuperation des options

while getopts P:S:s:d:h:n: c
do
   case $c in
      S)   SRCID=$OPTARG
           ;;
      P)   PRDID=$OPTARG
           ;;
      s)   SATIMG=$OPTARG
           ;;
      d)   YYYYMMDD=$OPTARG
           ;;
      h)   HHMN=$OPTARG
           ;;
      n)   NNNNN=$OPTARG
           ;;

      \?)  prd_exit 1 "erreur syntaxe : option non reconnue"
           ;;
   esac
done

shift `expr $OPTIND - 1`

# TODO : corriger avec une boucle.
# fichier source nr 1
if [ ! -z "`echo $1|grep CTh5`" ]; then
	FILE_SRC_CT=$1
elif [ ! -z "`echo $1|grep CTTh5`" ]; then
	FILE_SRC_CTT=$1
elif [ ! -z "`echo $1|grep CMICh5`" ]; then
	FILE_SRC_CMIC=$1
elif [ ! -z "`echo $1|grep RDTTar`" ]; then
	FILE_SRC_RDT=$1
fi
shift
# fichier source nr 2
if [ ! -z "`echo $1|grep CTh5`" ]; then
	FILE_SRC_CT=$1
elif [ ! -z "`echo $1|grep CTTh5`" ]; then
	FILE_SRC_CTT=$1
elif [ ! -z "`echo $1|grep CMICh5`" ]; then
	FILE_SRC_CMIC=$1
elif [ ! -z "`echo $1|grep RDTTar`" ]; then
	FILE_SRC_RDT=$1
fi

shift
# fichier source nr 3
if [ ! -z "`echo $1|grep CTh5`" ]; then
	FILE_SRC_CT=$1
elif [ ! -z "`echo $1|grep CTTh5`" ]; then
	FILE_SRC_CTT=$1
elif [ ! -z "`echo $1|grep CMICh5`" ]; then
	FILE_SRC_CMIC=$1
elif [ ! -z "`echo $1|grep RDTTar`" ]; then
	FILE_SRC_RDT=$1
fi

shift
# fichier source nr 4 
if [ ! -z "`echo $1|grep CTh5`" ]; then
	FILE_SRC_CT=$1
elif [ ! -z "`echo $1|grep CTTh5`" ]; then
	FILE_SRC_CTT=$1
elif [ ! -z "`echo $1|grep CMICh5`" ]; then
	FILE_SRC_CMIC=$1
elif [ ! -z "`echo $1|grep RDTTar`" ]; then
	FILE_SRC_RDT=$1
fi

shift
# fichier produit
#  TODO : à corriger pour rendre + robuste. 
FILE_PRD=$1
#controle source
#case $SRCID in
# CTTHh5) log_info "source $SRCID";;
# CMICh5) log_info "source $SRCID";;
# *)        log_info "source invalide : $SRCID"
#           prd_exit 1;;
#esac
#
log_info "ls SPOOL :"
ls SPOOL
log_info "ls WRK_SRC :"
ls WRK_SRC
#
test_CTT=`find WRK_SRC/ -name "CTTh5_${SATIMG}_${YYYYMMDD}_${HHMN}*"`
if [ -z $test_CTT ]; then
	log_info "produit CTTh5 (slot ${YYYYMMDD} ${HHMN} ) ABS > en attente, on sort"
	prd_exit 0
else
	FILE_SRC_CTT=$test_CTT
fi
#
test_CT=`find WRK_SRC/ -name "CTh5_${SATIMG}_${YYYYMMDD}_${HHMN}*"`
if [ -z $test_CT ]; then
	log_info "produit CTh5 (slot ${YYYYMMDD} ${HHMN} ) ABS > en attente, on sort"
	prd_exit 0
else
	FILE_SRC_CT=$test_CT
fi
#
test_CMIC=`find WRK_SRC/ -name "CMICh5_${SATIMG}_${YYYYMMDD}_${HHMN}*"`
if [ -z $test_CMIC ]; then
	log_info "produit CMICh5 (slot ${YYYYMMDD} ${HHMN} ) ABS > en attente, on sort"
	prd_exit 0
else
	FILE_SRC_CMIC=$test_CMIC
fi
#
test_RDT=`find WRK_SRC/ -name "RDTTar_${SATIMG}_${YYYYMMDD}_${HHMN}*"`
if [ -z $test_RDT ]; then
	log_info "produit RDT Tar (slot ${YYYYMMDD} ${HHMN} ) ABS > en attente, on sort"
	prd_exit 0
fi
log_info "les sources (CT, CTT, CMIC et RDT sont dispo pour le slot ${YYYYMMDD} ${HHMN}"
log_info "détarrage des RDT Tar pour extraire le fichier d'observation"
# étape de détarrage des nb (8 pour les  msg, 12 sur les goes, 8 sur hima) RDT Tar pour ne conserver que le fichier d'observation.
LST_RDT=`find WRK_SRC/ -name "RDTTar_*"`
log_info "Liste des fichiers tars RDT : ${LST_RDT}"
for tar in $LST_RDT ; do
  rdtObs=$(tar tf $tar | grep 'Z.nc')
  log_info "tar -f $tar -x $rdtObs"
  tar -f $tar -x $rdtObs
  if [ ! -f $rdtObs ]; then
    log_error "fichier $rdtObs absent : pb lors de la commande de détarrage du fichier $tar"
	prd_exit 1 
  fi
  #log_info "suppression du fichier $tar" # pour ne converser que le fichier d'obs dans WRK_SRc
  #rm -f $tar
done
# script pour vérifier que les sources RDT reçues sont cohérentes par rapport à l'heure de traitement
# permet d'annihiler le traitement des slots 0400 à 0545 utilisant, sinon, des sources de la veille.
check_presence_RDT.py --mode hard -dir . -v debug # avec ce mode, on n'autorise pas la fabrication du produit en l'absence d'une source RDT.
status=$?
if [ $status != 0 ]; then #peut valoir 1 si erreur de traitement, 2 si mode reprise activé et nb suffisant de sources RDT, 3 si trop de src mq (mode reprise) ou 1 src mq (mode hard). 
   log_info "controles des sources RDT > KO : pas de fabrication du produit ICRiskGT"
   prd_exit 0
else
   log_info "controles des sources RDT > OK : présentes et cohérentes."
fi
# 
log_info "fabrication du produit Ice Crystals Risk Water en cours..."
log_info "makeIceCrystalsRisk.py -cmic ${FILE_SRC_CMIC} -ctth ${FILE_SRC_CTT} -ct ${FILE_SRC_CT} -rdt . -out ${FILE_PRD}"
makeIceCrystalsRisk.py -cmic ${FILE_SRC_CMIC} -ctth ${FILE_SRC_CTT} -ct ${FILE_SRC_CT} -rdt . -out ${FILE_PRD}
test_return_code $? "check appel makeIceCrystalsRisk.py"
log_info "ls WRK_PRD:"
ls WRK_PRD
log_info "ls WRK_SRC :"
ls WRK_SRC		
# avant nettoyage des RDT
log_info "ls :"
ls		
test_RDT=`find . -name "S_NWC_RDT*nc*"`
if [ ! -z "${test_RDT}" ]; then
	log_info "nettoyage des fichiers d'obs. du RDT (liste des fichiers : ${test_RDT} )"
	find . -name "S_NWC_RDT*nc*" -delete
fi
#fi # 2 choix possibles.
#
prd_exit 0
# fin de traitement
#==============================================================================
# (C) METEO-FRANCE
#==============================================================================
